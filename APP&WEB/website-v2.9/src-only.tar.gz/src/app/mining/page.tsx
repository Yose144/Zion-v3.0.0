import MiningClient from '@/components/MiningClient';

export const metadata = {
  title: 'ZION Mining · Universal Orchestrator',
  description: 'Spin up the universal miner, ML orchestrator, and validator-grade stack powering Quantum Leap.',
};

export default function MiningPage() {
  return <MiningClient />;
}
