'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowDownToLine, CheckCircle2, Cpu, HardDrive, Shield, TerminalSquare } from 'lucide-react';

const builds = [
  {
    os: 'macOS · Apple Silicon',
    version: 'v2.9.0-rc2',
    checksum: 'a94c-rc2-mac-arm',
    size: '182 MB dmg',
    requirements: ['macOS 13 Ventura+', '8 GB RAM', 'Metal-capable GPU'],
    link: 'https://github.com/Zion-TerraNova/releases/macOS.dmg'
  },
  {
    os: 'Linux · x86_64',
    version: 'v2.9.0-rc2',
    checksum: 'b83f-rc2-linux-x64',
    size: '210 MB AppImage',
    requirements: ['Ubuntu 22.04 / Arch', '8 GB RAM', 'OpenCL / ROCm driver'],
    link: 'https://github.com/Zion-TerraNova/releases/linux.AppImage'
  },
  {
    os: 'Windows · x64',
    version: 'v2.9.0-rc2',
    checksum: 'c37d-rc2-win-x64',
    size: '195 MB installer',
    requirements: ['Windows 11', '8 GB RAM', 'DX12 GPU'],
    link: 'https://github.com/Zion-TerraNova/releases/win.exe'
  }
];

const steps = [
  {
    title: 'Verify download',
    items: [
      'Fetch latest release from official GitHub (no mirrors).',
      'Compare SHA256 checksum with release manifest.',
      'Use detached signature if running validators or large fleets.'
    ]
  },
  {
    title: 'Install + provision',
    items: [
      'Run installer / AppImage / dmg package.',
      'Allow driver access (OpenCL/Metal) and firewall exceptions.',
      'Import or create wallet + set payout address.'
    ]
  },
  {
    title: 'Connect to observatory',
    items: [
      'Select desired algorithms (Cosmic Harmony, RandomX, Yescrypt, Autolykos v2).',
      'Enable ML orchestrator auto-switch and energy optimizer.',
      'Point to pool ZION:3333 or custom stratum endpoint.'
    ]
  }
];

const requirements = [
  { label: 'CPU', value: '8-core modern CPU (Ryzen 7 / Apple M2+)' },
  { label: 'GPU', value: '8 GB VRAM (RX 5700+, RTX 3060+, or ROCm-capable)' },
  { label: 'Storage', value: '50 GB free SSD for chain cache + logs' },
  { label: 'Network', value: 'Reliable 20 Mbps uplink, low-latency path to pool' }
];

export default function DownloadPage() {
  return (
    <div className="min-h-screen pt-32 pb-24 px-4">
      <div className="container mx-auto max-w-5xl space-y-16">
        <motion.section
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-[32px] border border-white/10 bg-black/60 p-10 backdrop-blur-xl"
        >
          <div className="flex flex-col gap-6">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1 text-xs font-semibold tracking-[0.3em] text-zion-gold uppercase">
              <ArrowDownToLine className="h-4 w-4" />
              Native Miner Suite
            </div>
            <div>
              <p className="text-sm uppercase tracking-[0.4em] text-gray-400">Official builds only</p>
              <h1 className="text-5xl font-semibold text-gradient leading-tight">Download. Verify. Mine.</h1>
            </div>
            <p className="text-lg text-gray-300">
              These binaries ship with ML Orchestrator v3.0, four ASIC-resistant algorithms, warp-aware payout logic, and observatory telemetry.
              Always download from <Link href="https://github.com/Zion-TerraNova" className="underline decoration-zion-gold">github.com/Zion-TerraNova</Link> and verify signatures before running.
            </p>
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="space-y-6"
        >
          <div className="flex flex-col gap-2">
            <p className="text-sm uppercase tracking-[0.4em] text-gray-500">Choose your build</p>
            <h2 className="text-3xl font-semibold text-white">Release bundles · v2.9.0 RC2</h2>
          </div>
          <div className="space-y-5">
            {builds.map((build) => (
              <div key={build.os} className="rounded-3xl border border-white/10 bg-black/40 p-6">
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  <div>
                    <p className="text-xs uppercase tracking-[0.3em] text-gray-400">{build.version}</p>
                    <h3 className="text-2xl font-semibold text-white">{build.os}</h3>
                    <p className="text-sm text-gray-400">{build.size} · SHA256 {build.checksum}</p>
                  </div>
                  <Link
                    href={build.link}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 rounded-2xl bg-linear-to-r from-zion-gold to-zion-purple px-5 py-2 text-sm font-semibold text-black"
                  >
                    Download
                    <ArrowDownToLine className="h-4 w-4" />
                  </Link>
                </div>
                <div className="mt-4 flex flex-wrap gap-2 text-xs text-gray-300">
                  {build.requirements.map((req) => (
                    <span key={req} className="rounded-full border border-white/10 bg-white/5 px-3 py-1">
                      {req}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="rounded-[32px] border border-white/10 bg-white/5 p-8"
        >
          <div className="flex flex-col gap-2 mb-6">
            <p className="text-sm uppercase tracking-[0.4em] text-gray-500">Install playbook</p>
            <h2 className="text-3xl font-semibold text-white">3-step onboarding</h2>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            {steps.map((step, idx) => (
              <div key={step.title} className="rounded-3xl border border-white/10 bg-black/30 p-6">
                <div className="flex items-center gap-3">
                  <Shield className="h-5 w-5 text-zion-cyan" />
                  <p className="text-xs uppercase tracking-[0.35em] text-gray-400">Step {idx + 1}</p>
                </div>
                <h3 className="mt-3 text-xl font-semibold text-white">{step.title}</h3>
                <ul className="mt-4 space-y-2 text-sm text-gray-300">
                  {step.items.map((item) => (
                    <li key={item} className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-zion-gold mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="rounded-[32px] border border-white/10 bg-black/40 p-8"
        >
          <div className="flex flex-col gap-2 mb-6">
            <p className="text-sm uppercase tracking-[0.4em] text-gray-500">Hardware profile</p>
            <h2 className="text-3xl font-semibold text-white">Recommended specs</h2>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {requirements.map((req) => (
              <div key={req.label} className="rounded-2xl border border-white/10 bg-white/5 p-5">
                <div className="flex items-center gap-3">
                  <Cpu className="h-5 w-5 text-zion-gold" />
                  <p className="text-xs uppercase tracking-[0.3em] text-gray-400">{req.label}</p>
                </div>
                <p className="mt-3 text-lg text-white">{req.value}</p>
              </div>
            ))}
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, scale: 0.98 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.25 }}
          className="rounded-[32px] border border-zion-gold/30 bg-linear-to-r from-zion-purple/30 via-zion-gold/15 to-zion-purple/30 p-10 text-center"
        >
          <TerminalSquare className="mx-auto h-12 w-12 text-zion-gold" />
          <h2 className="mt-6 text-3xl font-semibold text-white">Need CI-friendly tarballs or container images?</h2>
          <p className="mt-4 text-gray-100 max-w-3xl mx-auto">
            Docker images, headless builds, and air-gapped bundles live in the same GitHub organization. Ping the team via issues/discussions and include your environment info so we can publish the right artifact.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <Link
              href="https://github.com/Zion-TerraNova"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-2xl bg-black/70 px-6 py-3 text-sm font-semibold text-white border border-white/20"
            >
              Browse releases
            </Link>
            <Link
              href="/docs"
              className="inline-flex items-center gap-2 rounded-2xl bg-white/90 px-6 py-3 text-sm font-semibold text-gray-900"
            >
              Deployment guides
            </Link>
          </div>
        </motion.section>
      </div>
    </div>
  );
}
