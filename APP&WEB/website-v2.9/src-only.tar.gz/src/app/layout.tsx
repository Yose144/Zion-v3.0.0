import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { ObservatoryProvider } from "@/contexts/ObservatoryContext";
import BackgroundOrchestrator from "@/components/BackgroundOrchestrator";
import ThemeToggle from "@/components/ThemeToggle";

const inter = Inter({ 
  subsets: ["latin"],
  variable: '--font-inter',
});

export const metadata: Metadata = {
  title: "ZION Blockchain v2.9 - Quantum Leap Revolution",
  description: "ZION Terra Nova: Multi-dimensional blockchain with consciousness-based mining, ML orchestrator, WARP liquidity, and native Dirigent roadmap",
  keywords: "blockchain, consciousness mining, ZION, cryptocurrency, quantum computing, ML orchestrator, WARP bridge, Rust native",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="cs" className="dark">
      <body className={`${inter.variable} antialiased bg-black text-white overflow-x-hidden`}>
        <ThemeProvider>
          <ObservatoryProvider>
            <BackgroundOrchestrator />
            <div className="relative z-10">
              <Navigation />
              <main className="min-h-screen">
                {children}
              </main>
              <Footer />
            </div>
            <ThemeToggle />
          </ObservatoryProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
