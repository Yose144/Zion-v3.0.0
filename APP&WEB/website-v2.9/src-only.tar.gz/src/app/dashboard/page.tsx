import type { Metadata } from "next";
import DashboardClient from '@/components/DashboardClient';

export const metadata: Metadata = {
  title: "Mission Control Dashboard · ZION v2.9 Quantum Leap",
  description: "Live systems dashboard: health checks, validator status, blockchain vitals, and operational roadmap for ZION Quantum Leap v2.9",
  keywords: "ZION dashboard, mission control, blockchain metrics, validator status, ML orchestrator, WARP bridge",
};

// Server-side data fetching
async function getBlockchainStats() {
  try {
    const res = await fetch('http://localhost:8001/blockchain/stats', {
      cache: 'no-store',
      headers: { 'Accept': 'application/json' }
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

async function getSystemHealth() {
  try {
    const res = await fetch('http://localhost:8001/health', {
      cache: 'no-store',
      headers: { 'Accept': 'application/json' }
    });
    const data = await res.json();
    return data;
  } catch {
    return { status: 'unknown', version: 'v2.8.9', uptime: 0 };
  }
}

async function getRecentBlocks() {
  try {
    const res = await fetch('http://localhost:8001/blockchain/blocks?limit=5', {
      cache: 'no-store',
      headers: { 'Accept': 'application/json' }
    });
    if (!res.ok) return [];
    return await res.json();
  } catch {
    return [];
  }
}

export default async function DashboardPage() {
  const [stats, health, blocks] = await Promise.all([
    getBlockchainStats(),
    getSystemHealth(),
    getRecentBlocks()
  ]);

  return <DashboardClient stats={stats} health={health} blocks={blocks} />;
}
