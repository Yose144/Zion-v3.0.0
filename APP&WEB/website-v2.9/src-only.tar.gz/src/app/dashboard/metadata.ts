import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Mission Control Dashboard · ZION v2.9 Quantum Leap",
  description: "Live systems dashboard: health checks, validator status, blockchain vitals, and operational roadmap for ZION Quantum Leap v2.9",
  keywords: "ZION dashboard, mission control, blockchain metrics, validator status, ML orchestrator, WARP bridge",
};
