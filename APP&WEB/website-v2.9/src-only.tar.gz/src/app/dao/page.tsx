'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight, Coins, Crown, Gavel, LayoutDashboard, ShieldCheck, Users } from 'lucide-react';

const daoStats = [
  { label: 'Treasury', value: '1.75B ZION', detail: 'Multi-sig 5-of-7 · time-lock 48h', icon: Coins },
  { label: 'Active proposals', value: '4 open', detail: 'Governance v2 console', icon: Gavel },
  { label: 'Community weight', value: '10k+ wallets', detail: '1 ZION = 1 vote w/ consciousness boost', icon: Users },
  { label: 'Audit status', value: 'Low risk', detail: 'Trail of Bits review scheduled', icon: ShieldCheck }
];

const phases = [
  {
    title: 'Phase 1 · Stewardship (2025)',
    bullets: [
      'Maitreya Buddha + Round Table guardians ensure uptime',
      'Emergency intervention + roadmap budget approvals',
      '90-day reporting cadence published in docs'
    ]
  },
  {
    title: 'Phase 2 · Hybrid DAO (2026)',
    bullets: [
      'Validator council joins guardians · 5-of-7 treasury',
      'On-chain proposal lifecycle (create → vote → execute)',
      'Golden Egg incentives + community matching pools'
    ]
  },
  {
    title: 'Phase 3 · Full DAO (2027+)',
    bullets: [
      'Treasury + roadmap fully controlled by stakers',
      'Quadratic or consciousness-weighted voting experiments',
      'Transparent grants + ecosystem investment committee'
    ]
  }
];

const proposals = [
  {
    id: '#42',
    title: 'Enable Security Hardening budget (Dec 1-15)',
    status: 'Voting closes in 36h',
    highlights: ['Fund cryptography migration + hardware wallets', 'Budget: 320M ZION', 'Requires 60% quorum']
  },
  {
    id: '#43',
    title: 'Performance sprint infrastructure',
    status: 'In discussion',
    highlights: ['Redis + WAL hardware purchase', 'Budget: 210M ZION', 'Benchmarks posted in docs/roadmaps']
  }
];

const quickLinks = [
  { label: 'Governance docs', href: '/docs', description: 'Proposal flow, voting power, emergency clauses.' },
  { label: 'Treasury dashboard', href: '/dashboard', description: 'Real-time balances, vesting schedules, tithe.' },
  { label: 'Join discussion', href: 'https://github.com/Zion-TerraNova', description: 'Open issues for proposals, comments, audits.' }
];

export default function DaoPage() {
  return (
    <div className="min-h-screen pt-32 pb-24 px-4">
      <div className="container mx-auto max-w-6xl space-y-16">
        <motion.section
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-[32px] border border-white/10 bg-black/60 p-10 backdrop-blur-xl"
        >
          <div className="flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">
            <div className="space-y-5">
              <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1 text-xs font-semibold tracking-[0.3em] text-zion-gold uppercase">
                <Crown className="h-4 w-4" />
                DAO 2.0 · Governance Hub
              </div>
              <div>
                <p className="text-sm uppercase tracking-[0.4em] text-gray-400">Treasury · proposals · rituals</p>
                <h1 className="text-5xl md:text-6xl font-semibold text-gradient leading-tight">Guiding the mission responsibly</h1>
              </div>
              <p className="text-lg text-gray-300 max-w-2xl">
                ZION&apos;s treasury funds ML sprints, warp bridges, and humanitarian tithes. Guardians maintain safety rails today,
                while staking participants gradually assume full control as the Native Dirigent rewrite and 2027 ignition approach.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link
                  href="/dashboard"
                  className="inline-flex items-center gap-2 rounded-2xl bg-linear-to-r from-zion-gold via-zion-purple to-zion-cyan px-6 py-3 text-sm font-semibold text-black"
                >
                  Open DAO dashboard
                  <ArrowRight className="h-4 w-4" />
                </Link>
                <Link
                  href="/docs"
                  className="inline-flex items-center gap-2 rounded-2xl border border-white/20 bg-white/5 px-6 py-3 text-sm font-semibold text-white"
                >
                  Review governance docs
                </Link>
              </div>
            </div>
            <div className="grid w-full gap-4 sm:grid-cols-2 lg:w-auto">
              {daoStats.map((stat) => (
                <div key={stat.label} className="rounded-2xl border border-white/10 bg-white/5 px-5 py-4 backdrop-blur">
                  <stat.icon className="h-6 w-6 text-zion-gold" />
                  <p className="mt-3 text-xs uppercase tracking-[0.3em] text-gray-400">{stat.label}</p>
                  <p className="text-3xl font-semibold text-white">{stat.value}</p>
                  <p className="text-sm text-gray-300">{stat.detail}</p>
                </div>
              ))}
            </div>
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="rounded-[32px] border border-white/10 bg-white/5 p-8"
        >
          <div className="flex flex-col gap-2 mb-6">
            <p className="text-sm uppercase tracking-[0.4em] text-gray-500">Governance phases</p>
            <h2 className="text-3xl font-semibold text-white">Road to full decentralization</h2>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            {phases.map((phase) => (
              <div key={phase.title} className="rounded-3xl border border-white/10 bg-black/30 p-6">
                <p className="text-xs uppercase tracking-[0.3em] text-gray-400">{phase.title}</p>
                <ul className="mt-4 space-y-2 text-sm text-gray-300">
                  {phase.bullets.map((item) => (
                    <li key={item} className="flex items-start gap-2">
                      <ShieldCheck className="h-4 w-4 text-zion-gold mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="rounded-[32px] border border-white/10 bg-black/40 p-8"
        >
          <div className="flex flex-col gap-2 mb-6">
            <p className="text-sm uppercase tracking-[0.4em] text-gray-500">Active proposals</p>
            <h2 className="text-3xl font-semibold text-white">Vote, comment, improve</h2>
          </div>
          <div className="space-y-5">
            {proposals.map((proposal) => (
              <div key={proposal.id} className="rounded-3xl border border-white/10 bg-white/5 p-6">
                <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
                  <div>
                    <p className="text-xs uppercase tracking-[0.3em] text-gray-400">{proposal.id}</p>
                    <h3 className="text-2xl font-semibold text-white">{proposal.title}</h3>
                  </div>
                  <span className="rounded-full border border-white/20 bg-black/30 px-3 py-1 text-xs text-gray-300">
                    {proposal.status}
                  </span>
                </div>
                <ul className="mt-4 space-y-2 text-sm text-gray-300">
                  {proposal.highlights.map((highlight) => (
                    <li key={highlight} className="flex items-start gap-2">
                      <LayoutDashboard className="h-4 w-4 text-zion-cyan mt-0.5" />
                      <span>{highlight}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, scale: 0.98 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.25 }}
          className="rounded-[32px] border border-zion-gold/30 bg-linear-to-r from-zion-purple/30 via-zion-gold/15 to-zion-purple/30 p-10"
        >
          <h2 className="text-3xl font-semibold text-white text-center">Helpful links</h2>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {quickLinks.map((link) => (
              <div key={link.label} className="rounded-2xl border border-white/10 bg-black/40 p-5">
                <p className="text-sm font-semibold text-white">{link.label}</p>
                <p className="mt-2 text-sm text-gray-300">{link.description}</p>
                <Link
                  href={link.href}
                  target={link.href.startsWith('http') ? '_blank' : undefined}
                  rel={link.href.startsWith('http') ? 'noreferrer' : undefined}
                  className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-zion-gold"
                >
                  Open
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            ))}
          </div>
        </motion.section>
      </div>
    </div>
  );
}
