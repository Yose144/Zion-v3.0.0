'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import Link from 'next/link';
import {
  ArrowUpRight,
  BookOpen,
  Compass,
  FileText,
  Github,
  Home,
  Search,
  Server,
  Sparkles
} from 'lucide-react';

const docs = [
  { id: 'index', title: '📚 Documentation Home', file: 'index.md', category: 'main' },
  { id: 'getting-started', title: '🚀 Getting Started', file: 'getting-started.md', category: 'main' },
  { id: 'setup', title: '⚙️ Setup Guide', file: 'setup.md', category: 'main' },
  
  { id: 'arch-overview', title: '🏗️ Architecture Overview', file: 'architecture/overview.md', category: 'architecture' },
  { id: 'arch-mining', title: '⛏️ Mining Architecture', file: 'architecture/mining.md', category: 'architecture' },
  
  { id: 'mining-guide', title: '⛏️ Mining Guide', file: 'mining-guide.md', category: 'guides' },
  { id: 'pool-setup', title: '🏊 Pool Setup', file: 'pool-setup.md', category: 'guides' },
  { id: 'api', title: '🔌 API Reference', file: 'api.md', category: 'guides' },
  
  { id: 'tutorial-index', title: '📖 Tutorials Overview', file: 'tutorials/index.md', category: 'tutorials' },
  { id: 'tutorial-dapp', title: '🎯 First DApp', file: 'tutorials/first-dapp.md', category: 'tutorials' },
  
  { id: 'whitepaper-full', title: '📄 Full Whitepaper v2.8.5', file: 'whitepaper/ZION_Whitepaper_v2.8.5.md', category: 'whitepaper' },
  { id: 'whitepaper-lite', title: '📝 Whitepaper Lite', file: 'whitepaper-lite.md', category: 'whitepaper' },
  { id: 'whitepaper-index', title: '� Whitepaper Index', file: 'whitepaper/index.md', category: 'whitepaper' },
  { id: 'whitepaper-governance', title: '🏛️ Governance', file: 'whitepaper/governance.md', category: 'whitepaper' },
  { id: 'whitepaper-security', title: '🔒 Security', file: 'whitepaper/security.md', category: 'whitepaper' },
  { id: 'whitepaper-roadmap', title: '🗺️ Roadmap Detail', file: 'whitepaper/roadmap.md', category: 'whitepaper' },
  
  { id: 'cosmic-map-full', title: '🌌 Cosmic Map (Public)', file: 'whitepaper/COSMIC_MAP_2.8.5_PUBLIC_EDITION.md', category: 'cosmic' },
  { id: 'cosmic-map-complete', title: '✨ Cosmic Map Complete', file: 'whitepaper/COSMIC_MAP_2.8.5_COMPLETE.md', category: 'cosmic' },
  { id: 'cosmic-map-readme', title: '� Cosmic Map Guide', file: 'whitepaper/COSMIC_MAP_2.8.5_PUBLIC_EDITION_README.md', category: 'cosmic' },
  
  { id: 'core-285', title: '⚙️ Core v2.8.5', file: 'whitepaper/CORE_2.8.5.md', category: 'advanced' },
  { id: 'sacred-knowledge', title: '🕉️ Sacred Knowledge', file: 'whitepaper/SACRED_KNOWLEDGE_2.8.5.md', category: 'advanced' },
  { id: 'humanitarian-tithe', title: '❤️ Humanitarian Tithe', file: 'whitepaper/HUMANITARIAN_TITHE_2.8.5.md', category: 'advanced' },
  { id: 'zion-oasis', title: '🏝️ ZION Oasis', file: 'whitepaper/ZION_OASIS_2.8.5.md', category: 'advanced' },
  { id: 'zion-victory', title: '🏆 ZION Victory 2025', file: 'whitepaper/ZION_VICTORY_2025.md', category: 'advanced' },
  { id: 'consciousness-levels', title: '🧠 Consciousness Levels', file: 'consciousness-levels.md', category: 'advanced' },
  { id: 'integration-web33', title: '🌐 Web 3.3 Integration', file: 'integration-web33.md', category: 'advanced' },
  { id: 'roadmap-lite', title: '🗺️ Roadmap Lite', file: 'roadmap-lite.md', category: 'advanced' },
  
  { id: 'faq', title: '❓ FAQ', file: 'faq.md', category: 'community' },
  { id: 'community', title: '👥 Community', file: 'community.md', category: 'community' },
  
  { id: 'legacy-index', title: '📦 Legacy Docs', file: 'legacy/index.md', category: 'legacy' },
  { id: 'legacy-core', title: '⚙️ Core 2.8.5', file: 'legacy/core-2-8-5.md', category: 'legacy' },
  { id: 'legacy-whitepaper', title: '📄 Whitepaper 2.8.5', file: 'legacy/whitepaper-2-8-5.md', category: 'legacy' },
];

const categories = [
  { key: 'main', label: '📌 Main' },
  { key: 'architecture', label: '🏗️ Architecture' },
  { key: 'guides', label: '📘 Guides' },
  { key: 'tutorials', label: '📖 Tutorials' },
  { key: 'whitepaper', label: '📄 Whitepaper' },
  { key: 'cosmic', label: '🌌 Cosmic Map' },
  { key: 'advanced', label: '🚀 Advanced' },
  { key: 'community', label: '👥 Community' },
  { key: 'legacy', label: '📦 Legacy' },
];

const docStats = [
  { label: 'Live documents', value: '34', detail: 'Guides, specs, rituals' },
  { label: 'API uptime', value: '99.9%', detail: 'Last 30 days' },
  { label: 'Latest release', value: 'v2.9.0-rc2', detail: 'Nov 12 update' },
  { label: 'AI rituals', value: '12', detail: 'Afterburner + Orchestrator' },
];

const heroActions = [
  { label: 'GitHub repo', href: 'https://github.com/Yose144/Zion-2.9', icon: Github, external: true },
  { label: 'API health', href: 'http://www.zionterranova.com:8001/health', icon: Server, external: true },
  { label: 'Roadmap', href: '/roadmap', icon: Compass, external: false },
];

const docQuickLinks = [
  { id: 'getting-started', title: 'Mission launch', description: 'Spin up node + wallet in minutes.' },
  { id: 'api', title: 'API reference', description: 'JSON-RPC, explorers, and pool endpoints.' },
  { id: 'arch-overview', title: 'Architecture map', description: 'Understand the mesh + consciousness layers.' },
  { id: 'whitepaper-roadmap', title: 'Roadmap detail', description: 'Phase-by-phase program plan.' },
];

const docSpotlights = [
  { id: 'mining-guide', title: 'Universal miner ritual', detail: 'Auto-rotate algorithms, optimize energy.', accent: 'from-zion-gold/20 to-zion-purple/20' },
  { id: 'pool-setup', title: 'Pool operations deck', detail: 'Docker, payouts, observability, treasury.', accent: 'from-zion-cyan/20 to-blue-500/20' },
  { id: 'consciousness-levels', title: 'Consciousness matrix', detail: 'Seven layers of rewards & tithe logic.', accent: 'from-rose-500/20 to-orange-400/20' },
];

export default function DocsPage() {
  const [selectedDoc, setSelectedDoc] = useState('index');
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');

  const activeDoc = docs.find((doc) => doc.id === selectedDoc) ?? docs[0];
  const activeCategoryLabel =
    categories.find((category) => category.key === activeDoc?.category)?.label ?? 'Docs';

  const filteredDocs = docs.filter((doc) => {
    if (!query.trim()) return true;
    const haystack = `${doc.title} ${doc.file} ${doc.category}`.toLowerCase();
    return haystack.includes(query.trim().toLowerCase());
  });

  useEffect(() => {
    async function loadDoc() {
      setLoading(true);
      try {
        const doc = docs.find((d) => d.id === selectedDoc);
        if (doc) {
          const response = await fetch(`/docs/${doc.file}`);
          const text = await response.text();
          setContent(text);
        }
      } catch (error) {
        console.error('Failed to load document:', error);
        setContent('# Error\n\nFailed to load document.');
      } finally {
        setLoading(false);
      }
    }

    loadDoc();
  }, [selectedDoc]);

  return (
    <div className="min-h-screen pt-32 pb-20 px-4">
      <div className="container mx-auto space-y-12">
        <motion.section
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-[36px] border border-white/10 bg-black/60 p-8 backdrop-blur-xl shadow-[0_30px_120px_rgba(0,0,0,0.5)]"
        >
          <div className="flex items-center gap-3 text-sm text-gray-400 mb-6">
            <Link
              href="/"
              className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-white/10 bg-white/5 text-zion-gold hover:text-white"
            >
              <Home className="h-5 w-5" />
            </Link>
            <span>/</span>
            <span>Documentation</span>
          </div>
          <div className="flex flex-col gap-8 xl:flex-row xl:items-center xl:justify-between">
            <div className="space-y-5">
              <div className="inline-flex items-center gap-2 rounded-full border border-zion-purple/40 bg-zion-purple/10 px-4 py-1 text-xs font-semibold uppercase tracking-[0.3em] text-zion-gold">
                <Sparkles className="h-4 w-4" /> Docs · API · Rituals
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-gradient leading-tight">
                Observatory Knowledge Grid
              </h1>
              <p className="text-gray-300 max-w-2xl">
                All guides, whitepapers, and consciousness protocols synced with the Quantum Leap build. Search,
                filter, and jump into the exact ritual you need without leaving mission control.
              </p>
              <div className="flex flex-wrap gap-3">
                {heroActions.map((action) => {
                  const ActionIcon = action.icon;
                  if (action.external) {
                    return (
                      <a
                        key={action.label}
                        href={action.href}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-2 rounded-2xl border border-white/15 bg-white/5 px-4 py-2 text-sm font-semibold text-gray-100 hover:border-zion-gold/60"
                      >
                        <ActionIcon className="h-4 w-4 text-zion-gold" />
                        {action.label}
                      </a>
                    );
                  }
                  return (
                    <Link
                      key={action.label}
                      href={action.href}
                      className="inline-flex items-center gap-2 rounded-2xl border border-white/15 bg-white/5 px-4 py-2 text-sm font-semibold text-gray-100 hover:border-zion-gold/60"
                    >
                      <ActionIcon className="h-4 w-4 text-zion-gold" />
                      {action.label}
                    </Link>
                  );
                })}
              </div>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              {docStats.map((stat) => (
                <div
                  key={stat.label}
                  className="rounded-3xl border border-white/10 bg-white/5 p-5 backdrop-blur"
                >
                  <p className="text-xs uppercase tracking-[0.3em] text-gray-400">{stat.label}</p>
                  <p className="text-3xl font-semibold text-white mt-2">{stat.value}</p>
                  <p className="text-sm text-gray-400">{stat.detail}</p>
                </div>
              ))}
            </div>
          </div>
        </motion.section>

        <div className="grid items-start gap-8 xl:grid-cols-[320px,1fr]">
          <aside className="space-y-6 rounded-[32px] border border-white/10 bg-black/60 p-6 backdrop-blur-xl sticky top-28 h-fit">
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-gray-400">Search docs</p>
              <div className="mt-3 flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm">
                <Search className="h-4 w-4 text-zion-gold" />
                <input
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Type ritual, API, pool..."
                  className="bg-transparent flex-1 text-gray-100 placeholder:text-gray-500 focus:outline-none"
                />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2 text-sm font-semibold text-white mb-3">
                <FileText className="h-4 w-4 text-zion-gold" />
                Contents
              </div>
              <div className="space-y-5 max-h-[55vh] overflow-y-auto pr-1">
                {categories.map((category) => {
                  const categoryDocs = filteredDocs.filter((doc) => doc.category === category.key);
                  if (!categoryDocs.length) return null;
                  return (
                    <div key={category.key}>
                      <div className="flex items-center justify-between text-[11px] font-semibold uppercase tracking-[0.3em] text-gray-400">
                        <span>{category.label}</span>
                        <span className="rounded-full bg-white/5 px-2 py-0.5 text-gray-300">{categoryDocs.length}</span>
                      </div>
                      <div className="mt-2 space-y-1">
                        {categoryDocs.map((doc) => (
                          <button
                            key={doc.id}
                            onClick={() => setSelectedDoc(doc.id)}
                            className={`w-full text-left rounded-2xl px-3 py-2 text-sm transition-colors ${
                              selectedDoc === doc.id
                                ? 'bg-linear-to-r from-zion-purple/30 to-zion-gold/20 text-white border border-zion-gold/40'
                                : 'text-gray-400 hover:text-white hover:bg-white/5'
                            }`}
                          >
                            {doc.title}
                          </button>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <div className="flex items-center gap-2 text-sm font-semibold text-white">
                <BookOpen className="h-4 w-4 text-zion-gold" /> Guided decks
              </div>
              <div className="mt-4 space-y-3">
                {docQuickLinks.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setSelectedDoc(item.id)}
                    className="flex w-full items-center justify-between rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-left hover:border-zion-gold/40"
                  >
                    <div>
                      <p className="text-sm font-semibold text-white">{item.title}</p>
                      <p className="text-xs text-gray-400">{item.description}</p>
                    </div>
                    <ArrowUpRight className="h-4 w-4 text-zion-gold" />
                  </button>
                ))}
              </div>
            </div>
          </aside>

          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-[32px] border border-white/10 bg-black/50 p-6 backdrop-blur"
            >
              <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                  <p className="text-xs uppercase tracking-[0.3em] text-gray-500">Now viewing</p>
                  <h2 className="text-3xl font-semibold text-white">{activeDoc.title}</h2>
                  <p className="text-sm text-gray-400">{activeDoc.file}</p>
                </div>
                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={() => setSelectedDoc('index')}
                    className="rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-semibold text-gray-200 hover:border-zion-gold/40"
                  >
                    Back to index
                  </button>
                  <a
                    href={`/docs/${activeDoc.file}`}
                    target="_blank"
                    rel="noreferrer"
                    className="rounded-2xl bg-linear-to-r from-zion-gold to-zion-purple px-4 py-2 text-sm font-semibold text-black"
                  >
                    Open raw file
                  </a>
                </div>
              </div>
              <div className="mt-4 flex flex-wrap gap-3 text-[11px] uppercase tracking-[0.3em] text-gray-400">
                <span className="rounded-full border border-white/10 px-3 py-1">{activeCategoryLabel}</span>
                <span className="rounded-full border border-white/10 px-3 py-1">
                  {filteredDocs.length} matching docs
                </span>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid gap-4 md:grid-cols-2 xl:grid-cols-3"
            >
              {docSpotlights.map((spotlight) => (
                <button
                  key={spotlight.id}
                  onClick={() => setSelectedDoc(spotlight.id)}
                  className={`rounded-3xl border border-white/10 bg-white/5 p-5 text-left hover:border-zion-gold/40`}
                >
                  <div className={`mb-4 h-10 w-10 rounded-2xl bg-linear-to-br ${spotlight.accent}`} />
                  <p className="text-sm uppercase tracking-[0.3em] text-gray-500">Spotlight</p>
                  <h3 className="text-xl font-semibold text-white">{spotlight.title}</h3>
                  <p className="text-sm text-gray-400 mt-1">{spotlight.detail}</p>
                </button>
              ))}
            </motion.div>

            <motion.div
              key={selectedDoc}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="rounded-[32px] border border-white/10 bg-black/60 p-8 backdrop-blur"
            >
              {loading ? (
                <div className="space-y-4">
                  <div className="h-6 w-1/2 rounded bg-white/10 animate-pulse" />
                  <div className="h-4 w-full rounded bg-white/10 animate-pulse" />
                  <div className="h-4 w-5/6 rounded bg-white/10 animate-pulse" />
                  <div className="h-4 w-4/6 rounded bg-white/10 animate-pulse" />
                </div>
              ) : (
                <div className="prose prose-invert max-w-none prose-headings:text-gradient prose-h1:text-4xl prose-h2:text-3xl prose-h3:text-2xl prose-p:text-gray-300 prose-p:leading-relaxed prose-code:text-zion-cyan prose-code:bg-white/10 prose-code:px-2 prose-code:py-1 prose-pre:bg-black/70 prose-pre:border prose-pre:border-white/10 prose-pre:rounded-xl prose-a:text-zion-cyan hover:prose-a:text-zion-gold prose-li:text-gray-300">
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>
                    {content}
                  </ReactMarkdown>
                </div>
              )}
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
