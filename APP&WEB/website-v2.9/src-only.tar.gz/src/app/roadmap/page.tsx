'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import {
  Activity,
  CalendarDays,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  Orbit,
  Rocket,
  ShieldCheck,
  Sparkles,
  Target,
  TrendingUp
} from 'lucide-react';

const summaryMetrics = [
  {
    title: 'Critical Path',
    value: '100%',
    description: 'ML Orchestrator + WARP 2.0 delivered (7 modules, 4k lines) as logged in the Nov 13 final report.',
    icon: CheckCircle2,
    color: 'from-emerald-500 to-lime-400'
  },
  {
    title: 'Quality & Testing',
    value: '1,200+',
    description: 'Unit, integration, load and fuzz suites run nightly with 0 regressions after validator dashboard launch.',
    icon: ClipboardCheck,
    color: 'from-blue-500 to-cyan-500'
  },
  {
    title: 'Bridge Reliability',
    value: '99.2%',
    description: 'Validator dashboard tracks BTC/ETH/SOL bridges with <0.8% failure rate and automated alerting.',
    icon: ShieldCheck,
    color: 'from-purple-500 to-pink-500'
  },
  {
    title: 'Native Trajectory',
    value: '12 mo',
    description: '2.9.1 “Native Dirigent” rewrite scheduled for a 12‑month runway before 2027 mainnet ignition.',
    icon: TrendingUp,
    color: 'from-yellow-500 to-orange-500'
  }
];

const completedWork = [
  {
    title: 'ML Orchestrator v3.0',
    description:
      'Seven production modules automate algorithm selection, profitability, difficulty, pricing, and energy strategy.',
    highlights: [
      'AI selector w/ 10–20% profit uplift + cooldown logic',
      'Difficulty predictor (RandomForest) w/ 2.3% MAPE',
      'Price predictor (Holt’s smoothing) with 95% CI + API hooks',
      'Energy optimizer with TOU pricing + thermal throttling'
    ]
  },
  {
    title: 'WARP 2.0 Bridges',
    description: 'Bitcoin, Ethereum, and Solana bridges audited with validator dashboard + liquidity pools online.',
    highlights: [
      'BTC HTLC swaps (SegWit/Taproot) + 2-of-3 multi-sig',
      'ETH lock/mint (5-of-7) + wZION contract + audit trail',
      'Solana SPL program w/ PDA + <400ms finality',
      'Validator dashboard + $5.5M TVL automated routing'
    ]
  },
  {
    title: 'Mining & Observability',
    description: 'Universal pool, native miners, dashboards, and alerting unified behind Prometheus + Grafana.',
    highlights: [
      'Stratum pool (PPLNS, Redis, WebSocket metrics)',
      'Native Cosmic Harmony/RandomX/Yescrypt/Autolykos builds',
      '12-service Docker stack with Loki + Alertmanager',
      'CI/CD for miners, orchestrator, and pool binaries'
    ]
  },
  {
    title: 'Governance & Docs',
    description: 'DAO 2.0 stack, treasury controls, and 2,500+ lines of fresh documentation shipped this sprint.',
    highlights: [
      'ZIONGovernance.sol + 5-of-7 treasury/timelock',
      'Next.js governance console (wagmi + viem)',
      'Roadmap, ML, bridge, and release reports published',
      'Operations runbooks + onboarding collateral refreshed'
    ]
  }
];

const inProgressWork = [
  {
    title: 'Security Hardening Sprint (30% complete)',
    progress: 30,
    window: 'Dec 1 – Dec 15, 2025',
    description:
      'Cryptography migration, hardware wallet flows, and external audit prep kicked off to unblock custodial partners.',
    highlights: [
      '🔄 ecdsa → cryptography library migration plan',
      '🔄 Ledger / Trezor command set + signing UX',
      '📅 Trail of Bits + bug bounty scheduling',
      '🛡️ Incident drills + penetration test rehearsal'
    ]
  },
  {
    title: 'Performance Optimization Sprint (20% complete)',
    progress: 20,
    window: 'Dec 16 – Dec 25, 2025',
    description:
      'Database tuning, caching, and benchmarking to hit <50ms queries and prep for 50k miner throughput.',
    highlights: [
      '🔄 SQLite WAL + indexing rollout on staging',
      '🔄 Redis caching (>80% hit rate goal)',
      '📊 Benchmark harness for miners/pool/API',
      '�️ Compact block relay + response compression'
    ]
  },
  {
    title: 'Native Stack 2.9.1 (Discovery → Dirigent)',
    progress: 5,
    window: 'Q1 – Q4 2025',
    description:
      '12‑month rewrite (Rust/C++) to replace the remaining 83% Python surface per ROADMAP_v2.9.1_NATIVE_REWRITE.md.',
    highlights: [
      '📐 Rust pool/core prototypes (10× throughput target)',
      '🧪 Cargo tests, fuzzing, and perf gates (>90% coverage)',
      '⚙️ LMDB state + libp2p networking design',
      '🧭 Gradual migration plan (feature flags + HAProxy)'
    ]
  }
];

const upcomingInitiatives = [
  {
    title: 'Security Hardening',
    target: 'Dec 1 – Dec 15, 2025',
    focus: [
      'Cryptography migration + hardware wallet rollout',
      'Trail of Bits engagement + bug bounty launch',
      'Incident drills, logging, and key custody runbooks'
    ]
  },
  {
    title: 'Performance Optimization',
    target: 'Dec 16 – Dec 25, 2025',
    focus: [
      'SQLite WAL + Redis caching in production',
      'Benchmark suite for miners/pool/API latency',
      'Compact blocks + API compression for RPC'
    ]
  },
  {
    title: 'Native Stack 2.9.1 Dirigent',
    target: 'Q1 – Q4 2025',
    focus: [
      'Rust/Tokio pool + blockchain prototypes',
      'LMDB state, libp2p networking, and RPC rewrite',
      'Fuzzing, audits, and parallel deployment plan'
    ]
  },
  {
    title: 'Migration & Performance Hardening',
    target: 'Q1 – Q3 2026',
    focus: [
      'Gradual traffic ramp (10% → 100%)',
      'Validator, liquidity, and exchange integrations',
      'DAO + governance activation across chains'
    ]
  },
  {
    title: 'Mainnet Launch & Exchanges',
    target: 'Q1 2027',
    focus: [
      'Release candidate + genesis ceremonies',
      '5+ exchange listings + $1M liquidity pool',
      'Community AMA, validator seeding, marketing rollout'
    ]
  }
];

const sprintTimeline = [
  {
    title: 'Weeks 1-2 · Nov 13 – Nov 26',
    focus: 'Universal miner integration + bridge testing',
    tasks: [
      'Wire ML Orchestrator into zion_universal_miner auto-switching',
      'Dry-run Bitcoin/Ethereum/Solana bridges on testnet',
      'Simulate 1,000 concurrent miners with validator telemetry'
    ]
  },
  {
    title: 'Weeks 3-4 · Nov 27 – Dec 10',
    focus: 'Dashboard polish + documentation',
    tasks: [
      'Ship web UI for validator dashboard + ML widgets',
      'Publish operator guides + governance handbooks',
      'Prep marketing collateral for exchanges and AMAs'
    ]
  },
  {
    title: 'Security Sprint · Dec 1 – Dec 15',
    focus: 'Hardening, audits, and hardware wallets',
    tasks: [
      'Swap ecdsa → cryptography + run regression tests',
      'Implement Ledger/Trezor signing UX end-to-end',
      'Kick off Trail of Bits audit + bug bounty operations'
    ]
  },
  {
    title: 'Performance Sprint · Dec 16 – Dec 25',
    focus: 'Caching, WAL, and benchmarking',
    tasks: [
      'Enable SQLite WAL + indexes with monitoring',
      'Roll out Redis caching and hit-rate tracking',
      'Publish benchmark suite for miners/pool/API latency'
    ]
  }
];

const versionHistory = [
  {
    title: 'v2.7.0 · Genesis Launch',
    period: 'Sep 2025',
    highlights: [
      'RandomX testnet, 60 s blocks, 144B total supply',
      'Baseline P2P + RPC stack recorded in VERSION_HISTORY_MAP',
      'CPU mining pools and wallets go live'
    ]
  },
  {
    title: 'v2.7.1 · Consciousness Network',
    period: 'Oct 2025',
    highlights: [
      'DAO governance blueprint + humanitarian tithe',
      '9-level consciousness mining multipliers documented in roadmaps',
      'Treasury + multi-sig guardrails for future DAO 2.0'
    ]
  },
  {
    title: 'v2.7.5 · Round Table & AI',
    period: 'Oct 2025',
    highlights: [
      '13-system AI Orchestrator + council framework',
      'Repository cleanup + production blockchain validation',
      'Docs synced with VERSION_HISTORY_MAP_PART1'
    ]
  },
  {
    title: 'v2.8.x · WARP Acceleration',
    period: 'Oct – Nov 2025',
    highlights: [
      'Ad Astra → Cosmic Harmony: GPU mining, 4 ASIC-resistant algos',
      'Unified production fixes, Redis/WAL perf gains, WebSocket analytics',
      '400+ tests, Prometheus stack, roadmap suites (see PART2 & PART3)'
    ]
  },
  {
    title: 'v2.9.0 · Quantum Leap',
    period: 'Nov 2025',
    highlights: [
      'ML Orchestrator v3.0, WARP 2.0 bridges, validator dashboard',
      'Critical path = 100% as logged in FINAL_REPORT_v2.9.0_SESSION',
      '$5.5M liquidity + audit prep for security sprint'
    ]
  },
  {
    title: 'v2.9.1 · Native Dirigent',
    period: '2025 – 2026',
    highlights: [
      '12‑month Rust/C++ rebuild targeting 50× miners & 100× TPS',
      'LMDB state, libp2p network, cargo test/fuzz per ROADMAP_v2.9.1',
      'Parallel rollout with feature flags + HAProxy routing'
    ]
  },
  {
    title: 'v3.0 · Mainnet Ignition',
    period: 'Q1 2027',
    highlights: [
      'Native stack GA, DAO treasury activation, exchange campaigns',
      'Validator seeding + liquidity targets met before launch window',
      'Community ceremonies + marketing window synced to official Git roadmap'
    ]
  }
];

const heroStats = [
  {
    label: 'Mainnet confidence',
    value: '92%',
    descriptor: 'All blockers tracked'
  },
  {
    label: 'Active squads',
    value: '6',
    descriptor: 'Core · AI · WARP · DAO'
  },
  {
    label: 'Critical risks',
    value: '0',
    descriptor: 'Post security review'
  },
  {
    label: 'Docs merged this week',
    value: '+18',
    descriptor: 'Roadmap + ops runbooks'
  }
];

export default function RoadmapPage() {
  return (
    <div className="min-h-screen pt-32 pb-24 px-4">
        <div className="container mx-auto max-w-6xl space-y-16">
          <motion.section
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-[32px] border border-white/10 bg-black/50 backdrop-blur-xl p-10 shadow-[0_30px_120px_rgba(0,0,0,0.45)]"
          >
            <div className="flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">
              <div className="space-y-5">
                <div className="inline-flex items-center gap-2 rounded-full border border-zion-purple/40 bg-zion-purple/10 px-4 py-1 text-xs font-semibold tracking-[0.3em] text-zion-gold uppercase">
                  <Target className="h-4 w-4" />
                  Quantum Leap · Phase 07
                </div>
                <div>
                  <p className="text-sm uppercase tracking-[0.4em] text-gray-400">Mission Control</p>
                  <h1 className="text-5xl md:text-6xl font-semibold text-gradient leading-tight">
                    Flight plan to mainnet ignition
                  </h1>
                </div>
                <p className="text-lg text-gray-300 max-w-2xl">
                  Every module, bridge, and AI ritual tracked in one console. Live metrics pull from the same
                  dashboards the core team uses—no vaporware, only verifiable progress.
                </p>
                <div className="flex flex-wrap gap-3 text-xs">
                  <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-gray-200">
                    <Sparkles className="h-3 w-3 text-zion-gold" /> Updated Nov 13, 2025
                  </span>
                  <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-gray-200">
                    <Orbit className="h-3 w-3 text-zion-cyan" /> Launch window · Q1 2027
                  </span>
                  <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-gray-200">
                    <ShieldCheck className="h-3 w-3 text-emerald-400" /> External audit booked
                  </span>
                </div>
              </div>
              <div className="grid w-full gap-4 sm:grid-cols-2 lg:w-auto">
                {heroStats.map((chip) => (
                  <div
                    key={chip.label}
                    className="rounded-2xl border border-white/10 bg-white/5 px-5 py-4 backdrop-blur"
                  >
                    <p className="text-xs uppercase tracking-[0.3em] text-gray-400">{chip.label}</p>
                    <p className="text-3xl font-semibold text-white mt-2">{chip.value}</p>
                    <p className="text-sm text-gray-300">{chip.descriptor}</p>
                  </div>
                ))}
              </div>
            </div>
          </motion.section>

          <motion.section
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="space-y-6"
          >
            <div className="flex flex-col gap-2">
              <p className="text-sm uppercase tracking-[0.4em] text-gray-500">Telemetry</p>
              <h2 className="text-3xl font-semibold text-white">Mission vitals</h2>
            </div>
            <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
              {summaryMetrics.map((metric, idx) => {
                const Icon = metric.icon;
                return (
                  <motion.div
                    key={metric.title}
                    initial={{ opacity: 0, y: 24 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.15 + idx * 0.05 }}
                    className="relative overflow-hidden rounded-3xl border border-white/10 bg-black/40 p-6"
                  >
                    <div className={`absolute inset-0 bg-linear-to-br ${metric.color} opacity-20 blur-2xl`} />
                    <div className="relative space-y-3">
                      <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center">
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <p className="text-xs uppercase tracking-[0.3em] text-gray-400">{metric.title}</p>
                      <p className="text-4xl font-semibold text-white">{metric.value}</p>
                      <p className="text-sm text-gray-300 leading-relaxed">{metric.description}</p>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.section>

          <motion.section
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="grid gap-8 lg:grid-cols-2"
          >
            <div className="rounded-[28px] border border-white/10 bg-linear-to-br from-zion-gold/10 via-transparent to-zion-purple/10 p-8">
              <div className="flex items-center justify-between gap-3">
                <h2 className="text-2xl font-semibold text-white flex items-center gap-3">
                  <CheckCircle2 className="h-6 w-6 text-emerald-400" />
                  Completed systems · Critical path ✅
                </h2>
                <span className="text-xs rounded-full border border-emerald-400/30 bg-emerald-400/10 px-3 py-1 text-emerald-200">
                  Production ready
                </span>
              </div>
              <p className="mt-4 text-sm text-gray-300">Runs today on https://zionterranova.com with full monitoring and auto failover.</p>
              <div className="mt-6 space-y-4">
                {completedWork.map((block) => (
                  <div key={block.title} className="rounded-2xl border border-white/10 bg-black/30 p-5">
                    <h3 className="text-lg font-semibold text-white">{block.title}</h3>
                    <p className="text-sm text-gray-300 mt-2">{block.description}</p>
                    <ul className="mt-4 space-y-2 text-sm text-gray-400">
                      {block.highlights.map((item) => (
                        <li key={item} className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 text-zion-gold mt-1" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-[28px] border border-white/10 bg-white/5 p-8 backdrop-blur-xl">
              <div className="flex items-center justify-between gap-3">
                <h2 className="text-2xl font-semibold text-white flex items-center gap-3">
                  <Activity className="h-6 w-6 text-zion-cyan" />
                  Active build streams
                </h2>
                <span className="text-xs rounded-full border border-blue-500/30 bg-blue-500/10 px-3 py-1 text-blue-200">
                  Sprint S37
                </span>
              </div>
              <p className="mt-4 text-sm text-gray-300">Hardware orchestration, warp bridges, and governance releases stacked in the next 3 weeks.</p>
              <div className="mt-6 space-y-5">
                {inProgressWork.map((block, idx) => (
                  <div key={block.title} className="rounded-2xl border border-white/10 bg-black/30 p-5">
                    <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
                      <div>
                        <h3 className="text-lg font-semibold text-white">{block.title}</h3>
                        <p className="text-xs text-gray-400">{block.window}</p>
                      </div>
                      <motion.span
                        initial={{ width: 0 }}
                        whileInView={{ width: 'auto' }}
                        viewport={{ once: true }}
                        transition={{ delay: idx * 0.05 }}
                        className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs"
                      >
                        <Clock className="h-3 w-3 text-zion-cyan" /> {block.progress}%
                      </motion.span>
                    </div>
                    <p className="mt-3 text-sm text-gray-300">{block.description}</p>
                    <div className="mt-4">
                      <div className="h-2 rounded-full bg-white/10">
                        <motion.div
                          initial={{ width: 0 }}
                          whileInView={{ width: `${block.progress}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 0.7, delay: 0.1 + idx * 0.05 }}
                          className="h-2 rounded-full bg-linear-to-r from-blue-500 via-zion-cyan to-zion-purple"
                        />
                      </div>
                      <div className="mt-2 grid gap-2 text-sm text-gray-300">
                        {block.highlights.map((item) => (
                          <div key={item} className="flex items-start gap-2">
                            <CheckCircle2 className="h-4 w-4 text-zion-cyan mt-0.5" />
                            <span>{item}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.section>

          <motion.section
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25 }}
            className="rounded-[32px] border border-white/10 bg-black/40 p-8"
          >
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-sm uppercase tracking-[0.4em] text-gray-500">Signal horizon</p>
                <h2 className="text-3xl font-semibold text-white flex items-center gap-3">
                  <CalendarDays className="h-7 w-7 text-zion-gold" />
                  Upcoming milestones
                </h2>
              </div>
              <p className="text-sm text-gray-400 max-w-xl">
                Four workstreams run in parallel with hardened security, economic prep, and exchange enablement.
              </p>
            </div>
            <div className="mt-8 grid gap-6 md:grid-cols-2">
              {upcomingInitiatives.map((item, idx) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.05 }}
                  className="rounded-2xl border border-white/10 bg-white/5 p-5"
                >
                  <div className="flex items-center justify_between">
                    <h3 className="text-xl font-semibold text-white">{item.title}</h3>
                    <span className="text-xs rounded-full border border-white/20 bg-black/30 px-3 py-1 text-gray-300">{item.target}</span>
                  </div>
                  <ul className="mt-4 space-y-2 text-sm text-gray-300">
                    {item.focus.map((focus) => (
                      <li key={focus} className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-zion-gold mt-0.5" />
                        <span>{focus}</span>
                      </li>
                    ))}
                  </ul>
                </motion.div>
              ))}
            </div>
          </motion.section>

          <motion.section
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="rounded-[32px] border border-white/10 bg-white/5 p-8"
          >
            <h2 className="text-center text-3xl font-semibold text-gradient mb-10">Next 30 days · execution plan</h2>
            <div className="relative">
              <div className="absolute left-6 top-0 bottom-0 w-[2px] bg-linear-to-b from-zion-gold via-zion-purple to-zion-cyan" />
              <div className="space-y-8">
                {sprintTimeline.map((entry, idx) => (
                  <motion.div
                    key={entry.title}
                    initial={{ opacity: 0, y: 24 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.05 }}
                    className="relative flex gap-6"
                  >
                    <div className="relative z-10 mt-1 flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-white/20 bg-black/60 text-[10px] font-semibold uppercase tracking-widest text-gray-300">
                      {entry.title.split('·')[0].trim()}
                    </div>
                    <div className="flex-1 rounded-3xl border border-white/10 bg-black/30 p-6">
                      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                        <div>
                          <h3 className="text-xl font-semibold text-white">{entry.title}</h3>
                          <p className="text-sm text-gray-400">{entry.focus}</p>
                        </div>
                        <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-gray-300">
                          <Activity className="h-3 w-3 text-zion-cyan" /> Sprint {idx + 1}
                        </div>
                      </div>
                      <ul className="mt-4 space-y-2 text-sm text-gray-300">
                        {entry.tasks.map((task) => (
                          <li key={task} className="flex items-start gap-2">
                            <CheckCircle2 className="h-4 w-4 text-zion-cyan mt-0.5" />
                            <span>{task}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.section>

          <motion.section
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.35 }}
            className="rounded-[32px] border border-zion-gold/30 bg-linear-to-r from-zion-purple/30 via-zion-gold/15 to-zion-purple/30 p-10 text-center"
          >
            <Rocket className="mx-auto h-12 w-12 text-zion-gold" />
            <h2 className="mt-6 text-3xl font-semibold text-white">Mainnet ignition · Q1 2027</h2>
            <p className="mt-4 text-gray-100 max-w-3xl mx-auto">
              Mainnet shifts to coincide with the v2.9.1 “Native Dirigent” rewrite: native pool/core, audited migrations, and full DAO activation.
              Security + performance sprints run in 2025, migration waves in 2026, and the ignition window opens Q1 2027.
            </p>
            <div className="mt-6 flex flex-wrap items-center justify-center gap-3 text-xs text-gray-900">
              {['10k+ wallets ready', '50k miner capacity target', '$1M liquidity pool', '5+ exchange listings'].map((item) => (
                <span key={item} className="rounded-full bg-white/80 px-4 py-2 font-semibold text-gray-900">
                  {item}
                </span>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
              <Link
                href="/docs"
                className="inline-flex items-center gap-2 rounded-2xl bg-black/70 px-6 py-3 text-sm font-semibold text-white border border-white/20"
              >
                Dive into documentation
              </Link>
              <Link
                href="/dashboard"
                className="inline-flex items-center gap-2 rounded-2xl bg-linear-to-r from-zion-gold to-zion-purple px-6 py-3 text-sm font-semibold text-black"
              >
                Monitor live systems
              </Link>
            </div>
          </motion.section>

          <motion.section
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="rounded-[32px] border border-white/10 bg-black/40 p-8"
          >
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-sm uppercase tracking-[0.4em] text-gray-500">Version log</p>
                <h2 className="text-3xl font-semibold text-white">History beneath the launch pad</h2>
              </div>
              <p className="text-sm text-gray-400 max-w-xl">
                Snapshot pulled from docs/roadmaps and VERSION_HISTORY maps so supporters can trace every release leading to the 2027 ignition.
              </p>
            </div>
            <div className="mt-8 grid gap-6 md:grid-cols-2">
              {versionHistory.map((entry, idx) => (
                <motion.div
                  key={entry.title}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.05 }}
                  className="rounded-2xl border border-white/10 bg-white/5 p-5"
                >
                  <div className="flex items-center justify-between gap-3">
                    <h3 className="text-xl font-semibold text-white">{entry.title}</h3>
                    <span className="text-xs rounded-full border border-white/20 bg-black/30 px-3 py-1 text-gray-300">{entry.period}</span>
                  </div>
                  <ul className="mt-4 space-y-2 text-sm text-gray-300">
                    {entry.highlights.map((highlight) => (
                      <li key={highlight} className="flex items-start gap-2">
                        <Clock className="h-4 w-4 text-zion-gold mt-0.5" />
                        <span>{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </motion.div>
              ))}
            </div>
          </motion.section>
        </div>
      </div>
    );
  }
