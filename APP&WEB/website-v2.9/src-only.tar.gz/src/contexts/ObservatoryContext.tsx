"use client";

import React, { createContext, useContext, useEffect, useMemo, useState } from "react";

export type ObservatoryMode = "deep-space" | "planet-orbit" | "galactic-core";

type ObservatoryContextType = {
  mode: ObservatoryMode;
  setMode: (mode: ObservatoryMode) => void;
  availableModes: { id: ObservatoryMode; label: string; description: string }[];
};

const ObservatoryContext = createContext<ObservatoryContextType | null>(null);

const MODES: ObservatoryContextType["availableModes"] = [
  { id: "deep-space", label: "Deep Space", description: "Flight through the cosmos" },
  { id: "planet-orbit", label: "Planet Orbit", description: "AI / Mining Observatory" },
  { id: "galactic-core", label: "Galactic Core", description: "WARP & DAO view" },
];

const STORAGE_KEY = "zion-observatory-mode";

function getStoredMode(): ObservatoryMode {
  if (typeof window === 'undefined') {
    return 'deep-space';
  }
  const stored = localStorage.getItem(STORAGE_KEY) as ObservatoryMode | null;
  return stored && MODES.find((m) => m.id === stored) ? stored : 'deep-space';
}

export function ObservatoryProvider({ children }: { children: React.ReactNode }) {
  const [mode, setMode] = useState<ObservatoryMode>(() => getStoredMode());

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, mode);
  }, [mode]);

  const value = useMemo(
    () => ({ mode, setMode, availableModes: MODES }),
    [mode]
  );

  return <ObservatoryContext.Provider value={value}>{children}</ObservatoryContext.Provider>;
}

export function useObservatory() {
  const ctx = useContext(ObservatoryContext);
  if (!ctx) {
    throw new Error("useObservatory must be used within ObservatoryProvider");
  }
  return ctx;
}
