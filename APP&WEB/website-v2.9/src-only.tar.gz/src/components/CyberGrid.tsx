'use client';
import { useEffect, useRef } from 'react';
import { useTheme } from '@/contexts/ThemeContext';

export default function CyberGrid() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { currentTheme } = useTheme();
  const themeName = currentTheme.name;

  useEffect(() => {
    if (themeName !== 'cyberpunk') return;
  const canvas = canvasRef.current; if (!canvas) return;
  const ctx = canvas.getContext('2d'); if (!ctx) return;
  const c = canvas as HTMLCanvasElement;
  const context = ctx as CanvasRenderingContext2D;

    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
    resize();

    let t = 0;
    function draw() {
  if (themeName !== 'cyberpunk') return;
  context.clearRect(0,0,c.width,c.height);
  context.strokeStyle = 'rgba(255,0,255,0.25)';
  context.lineWidth = 1;
      const spacing = 40;

      // vertical lines
      for (let x=0; x<c.width; x+=spacing) {
        context.beginPath();
        context.moveTo(x, 0);
        const wave = Math.sin((x + t) * 0.02) * 10;
        context.lineTo(x + wave, c.height);
        context.stroke();
      }
      // horizontal lines
      for (let y=0; y<c.height; y+=spacing) {
        context.beginPath();
        const wave = Math.cos((y + t) * 0.02) * 10;
        context.moveTo(0, y);
        context.lineTo(c.width, y + wave);
        context.stroke();
      }

      t += 1.5;
      requestAnimationFrame(draw);
    }
    draw();

    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, [themeName]);

  return themeName === 'cyberpunk' ? (
    <canvas ref={canvasRef} className="fixed inset-0 -z-20 opacity-60" />
  ) : null;
}
