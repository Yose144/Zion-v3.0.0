'use client';

import { useEffect, useRef } from 'react';

type RGBColor = [number, number, number];

interface StarfieldBackgroundProps {
  starColor?: RGBColor;
  density?: number;
  speed?: number;
  trailOpacity?: number;
  backgroundGradient?: string;
}

const DEFAULT_COLOR: RGBColor = [255, 215, 0];
const DEFAULT_GRADIENT = 'radial-gradient(ellipse at bottom, #1B2735 0%, #090A0F 100%)';

export default function StarfieldBackground({
  starColor = DEFAULT_COLOR,
  density = 220,
  speed = 2,
  trailOpacity = 0.1,
  backgroundGradient = DEFAULT_GRADIENT,
}: StarfieldBackgroundProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const stars: { x: number; y: number; z: number; size: number }[] = [];

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    const seedStars = () => {
      stars.splice(0, stars.length);
      for (let i = 0; i < density; i++) {
        stars.push({
          x: Math.random() * canvas.width - canvas.width / 2,
          y: Math.random() * canvas.height - canvas.height / 2,
          z: Math.random() * canvas.width,
          size: Math.random() * 2 + 0.5,
        });
      }
    };

    resize();
    seedStars();

    let animationFrameId: number;

    const animate = () => {
      if (!ctx || !canvas) return;

      ctx.fillStyle = `rgba(0, 0, 0, ${Math.min(Math.max(trailOpacity, 0.02), 0.3)})`;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      stars.forEach((star) => {
        star.z -= speed;
        if (star.z <= 0) {
          star.z = canvas.width;
          star.x = Math.random() * canvas.width - canvas.width / 2;
          star.y = Math.random() * canvas.height - canvas.height / 2;
        }

        const x = (star.x / star.z) * canvas.width + canvas.width / 2;
        const y = (star.y / star.z) * canvas.height + canvas.height / 2;
        const size = (1 - star.z / canvas.width) * star.size * 2;

        const brightness = 1 - star.z / canvas.width;
        const alpha = Math.min(1, 0.15 + brightness * 0.85);
        ctx.fillStyle = `rgba(${starColor[0]}, ${starColor[1]}, ${starColor[2]}, ${alpha})`;
        ctx.beginPath();
        ctx.arc(x, y, Math.max(size, 0.4), 0, Math.PI * 2);
        ctx.fill();
      });

      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      resize();
      seedStars();
    };

    window.addEventListener('resize', handleResize);

    return () => {
      if (animationFrameId) cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, [density, speed, starColor, trailOpacity]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full -z-30"
      style={{ background: backgroundGradient }}
    />
  );
}
