"use client";

import Link from 'next/link';
import { motion } from 'framer-motion';
import { BookOpen, Brain, Cpu, Gauge, Network, Radar, Zap } from 'lucide-react';

const protocols = [
  {
    title: 'Universal miner',
    description: 'Rust core + Python commander, rotates RandomX ⇄ Yescrypt ⇄ Autolykos v2 ⇄ KawPow with ML heuristics.',
    icon: Cpu
  },
  {
    title: 'AI pool orchestrator',
    description: 'Observability hooks feed the consciousness mining AI: block propagation, latency, power budgets.',
    icon: Brain
  },
  {
    title: 'Critical-path telemetry',
    description: 'RPC, stratum, GPU/CPU fleet, and guardian validators streamed into Grafana + WARP 2.0.',
    icon: Radar
  }
];

const supportedAlgorithms = [
  { name: 'RandomX', type: 'CPU', detail: 'Orchestrator default · Ryzen/Epyc tuned', port: '3335', algo: 'randomx' },
  { name: 'Yescrypt', type: 'CPU', detail: 'Memory-hard · Great for ARM/Linux SBCs', port: '3336', algo: 'yescrypt' },
  { name: 'Autolykos v2', type: 'GPU', detail: '6GB+ VRAM cards · ERGO heritage', port: '3337', algo: 'autolykos2' },
  { name: 'KawPow', type: 'GPU', detail: 'RTX 20/30/40 + RX 6000 fleets', port: '3338', algo: 'kawpow' }
];

const minerSteps = [
  {
    title: 'Clone & install',
    code: 'git clone https://github.com/zion-net/Zion-2.9.git\ncd Zion-2.9/ai\npip install -r requirements-ai.txt'
  },
  {
    title: 'Start orchestrator',
    code: './start_ai_orchestrator.sh --network mainnet --pool www.zionterranova.com:3335'
  },
  {
    title: 'Launch universal miner',
    code: `python ai/zion_universal_miner.py \
  --wallet YOUR_ZION_ADDRESS \
  --pool www.zionterranova.com:3335 \
  --algorithm randomx \
  --rotate-interval 3600`
  }
];

const alternativeStacks = [
  { name: 'XMRig', usage: 'RandomX tuned for modern CPUs', link: 'https://github.com/xmrig/xmrig' },
  { name: 'cpuminer-opt', usage: 'Yescrypt / CPU multi algo', link: 'https://github.com/JayDDee/cpuminer-opt' },
  { name: 'lolMiner', usage: 'Autolykos v2 / AMD + NVIDIA', link: 'https://lolminer.site/' },
  { name: 'T-Rex', usage: 'KawPow / NVIDIA optimized', link: 'https://trex-miner.com/' }
];

export default function MiningClient() {
  return (
    <div className="min-h-screen px-4 pt-32 pb-20">
      <div className="container mx-auto max-w-5xl space-y-10">
  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="rounded-4xl border border-white/10 bg-black/60 p-10 backdrop-blur-xl text-center">
          <p className="text-sm uppercase tracking-[0.4em] text-gray-500">Quantum Leap mining stack</p>
          <h1 className="text-5xl md:text-6xl font-semibold text-gradient mt-4">Universal miner + ML orchestrator</h1>
          <p className="mt-6 text-lg text-gray-300">
            Same playbook core contributors use to maintain validators, GPU farms, and consciousness mining telemetry across BTC · ETH · SOL bridges.
          </p>
        </motion.div>

        <div className="grid gap-6 md:grid-cols-3">
          {protocols.map((protocol) => (
            <motion.div
              key={protocol.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="rounded-3xl border border-white/10 bg-linear-to-br from-zion-gold/10 via-zion-purple/5 to-zion-cyan/10 p-6"
            >
              <protocol.icon className="h-10 w-10 text-zion-gold" />
              <h3 className="mt-4 text-xl font-semibold text-white">{protocol.title}</h3>
              <p className="mt-2 text-sm text-gray-300">{protocol.description}</p>
            </motion.div>
          ))}
        </div>

        <motion.section initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="rounded-[28px] border border-white/10 bg-black/50 p-8">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-gray-400">Pool access</p>
              <h2 className="text-3xl font-semibold text-white">Stratum endpoints</h2>
              <p className="text-sm text-gray-400">Auto-detect or pin a specific algorithm port.</p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-mono text-zion-cyan">stratum+tcp://www.zionterranova.com:3335</div>
          </div>
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            {supportedAlgorithms.map((algo) => (
              <div key={algo.name} className="rounded-2xl border border-white/10 bg-white/5 p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-lg font-semibold text-white">{algo.name}</p>
                    <p className="text-xs uppercase tracking-[0.3em] text-gray-400">{algo.type}</p>
                  </div>
                  <span className="rounded-full bg-black/50 px-4 py-1 text-sm text-zion-cyan">:{algo.port}</span>
                </div>
                <p className="mt-3 text-sm text-gray-300">{algo.detail}</p>
                <p className="mt-1 text-xs text-gray-500">CLI flag: <code className="text-zion-gold">--algorithm {algo.algo}</code></p>
              </div>
            ))}
          </div>
        </motion.section>

        <motion.section initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="rounded-[28px] border border-white/10 bg-black/50 p-8">
          <div className="flex items-center gap-3">
            <Zap className="h-6 w-6 text-zion-gold" />
            <h2 className="text-3xl font-semibold text-white">Command center</h2>
          </div>
          <p className="mt-2 text-sm text-gray-400">Universal miner rotates algorithms, streams telemetry to the AI orchestrator, and feeds consciousness multipliers.</p>
          <div className="mt-6 grid gap-4">
            {minerSteps.map((step, idx) => (
              <div key={step.title} className="rounded-2xl border border-white/10 bg-white/5 p-6">
                <p className="text-xs uppercase tracking-[0.3em] text-gray-400">Step {idx + 1}</p>
                <h3 className="mt-2 text-xl font-semibold text-white">{step.title}</h3>
                <pre className="mt-4 rounded-2xl border border-white/10 bg-black/60 p-4 text-sm text-gray-200 overflow-x-auto">
{step.code}
                </pre>
              </div>
            ))}
          </div>
          <div className="mt-4 text-sm text-gray-400">
            Tip: add <code className="text-zion-cyan">--power-cap 180</code> or <code className="text-zion-cyan">--rotate-interval 900</code> to dynamically balance GPU thermals with consciousness multipliers.
          </div>
        </motion.section>

        <motion.section initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="rounded-[28px] border border-white/10 bg-black/50 p-8">
          <div className="flex items-center gap-3 mb-4">
            <Gauge className="h-6 w-6 text-zion-gold" />
            <h2 className="text-3xl font-semibold text-white">Alternative stacks</h2>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {alternativeStacks.map((stack) => (
              <div key={stack.name} className="rounded-2xl border border-white/10 bg-white/5 p-5 flex flex-col">
                <div className="flex items-center gap-3">
                  <Network className="h-5 w-5 text-zion-cyan" />
                  <div>
                    <p className="text-lg font-semibold text-white">{stack.name}</p>
                    <p className="text-sm text-gray-400">{stack.usage}</p>
                  </div>
                </div>
                <Link href={stack.link} target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center gap-2 text-sm text-zion-cyan">
                  Download
                  ↗
                </Link>
              </div>
            ))}
          </div>
        </motion.section>

  <motion.section initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="rounded-4xl border border-white/10 bg-linear-to-r from-zion-gold/10 via-zion-purple/10 to-zion-cyan/10 p-10 text-center">
          <BookOpen className="mx-auto h-12 w-12 text-zion-gold" />
          <h2 className="mt-4 text-3xl font-semibold text-white">Need full playbooks?</h2>
          <p className="mt-3 text-base text-gray-200 max-w-3xl mx-auto">
            Deep dives live inside docs, FINAL_REPORT_v2.9.0_SESSION, and the /download pack (benchmarks, config templates, observability dashboards).
          </p>
          <div className="mt-6 flex flex-col gap-4 md:flex-row md:justify-center">
            <Link href="/docs" className="rounded-2xl bg-white/80 px-8 py-3 text-black font-semibold">Open docs</Link>
            <Link href="/download" className="rounded-2xl border border-white/50 px-8 py-3 text-white">Get builder pack</Link>
          </div>
        </motion.section>
      </div>
    </div>
  );
}
