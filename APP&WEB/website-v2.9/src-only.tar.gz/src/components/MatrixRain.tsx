'use client';
import { useEffect, useRef } from 'react';
import { useTheme } from '@/contexts/ThemeContext';

export default function MatrixRain() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { currentTheme } = useTheme();
  const themeName = currentTheme.name;

  useEffect(() => {
    if (themeName !== 'matrix') return;
  const canvas = canvasRef.current; if (!canvas) return;
  const ctx = canvas.getContext('2d'); if (!ctx) return;
  const c = canvas as HTMLCanvasElement;
  const context = ctx as CanvasRenderingContext2D;

  const resize = () => { c.width = window.innerWidth; c.height = window.innerHeight; };
    resize();

    const chars = '01Ƶ∴✶✧※';
    const fontSize = 16;
  const columns = Math.floor(c.width / fontSize);
    const drops: number[] = new Array(columns).fill(1);

    function draw() {
      if (themeName !== 'matrix') return; // stop drawing if changed
      context.fillStyle = 'rgba(0,0,0,0.08)';
      context.fillRect(0,0,c.width,c.height);
      context.fillStyle = '#00ff41';
      context.font = fontSize + 'px monospace';
      for (let i=0;i<drops.length;i++) {
        const text = chars[Math.floor(Math.random()*chars.length)];
        context.fillText(text, i*fontSize, drops[i]*fontSize);
        if (drops[i]*fontSize > c.height && Math.random() > 0.975) drops[i] = 0;
        drops[i]++;
      }
      requestAnimationFrame(draw);
    }
    draw();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, [themeName]);

  return themeName === 'matrix' ? (
    <canvas ref={canvasRef} className="fixed inset-0 -z-20 opacity-70" />
  ) : null;
}
