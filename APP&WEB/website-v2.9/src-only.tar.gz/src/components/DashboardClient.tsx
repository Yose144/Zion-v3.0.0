'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  Activity,
  ArrowRight,
  Cpu,
  Gauge,
  ShieldCheck,
  SignalHigh,
  TrendingUp,
  Zap
} from 'lucide-react';

interface DashboardClientProps {
  stats: any;
  health: any;
  blocks: any[];
}

const missionMetrics = [
  {
    label: 'Critical path',
    value: '100%',
    description: 'ML Orchestrator + WARP 2.0 delivered',
    icon: Zap
  },
  {
    label: 'Validator uptime',
    value: '99.2%',
    description: '7-of-7 guardians online',
    icon: ShieldCheck
  },
  {
    label: 'Liquidity locked',
    value: '$5.5M',
    description: 'BTC · ETH · SOL · USDC pools',
    icon: Gauge
  },
  {
    label: 'Launch window',
    value: 'Q1 2027',
    description: 'After Native Dirigent rollout',
    icon: SignalHigh
  }
];

const roadmapSlices = [
  {
    title: 'Security Sprint · Dec 1-15',
    bullets: ['Cryptography migration (ecdsa → cryptography)', 'Ledger/Trezor wallet flows', 'Trail of Bits audit + bug bounty']
  },
  {
    title: 'Performance Sprint · Dec 16-25',
    bullets: ['SQLite WAL + Redis caching rollout', 'Benchmark suite (miners/pool/API)', 'Compact block relay + compression']
  },
  {
    title: 'Native Dirigent · 2025/26',
    bullets: ['Rust/Tokio pool + LMDB core prototypes', 'libp2p networking + cargo fuzz', 'HAProxy traffic ramp plan']
  }
];

export default function DashboardClient({ stats, health, blocks }: DashboardClientProps) {
  const computedUptime = health?.uptime ? `${Math.floor(health.uptime / 3600)}h` : '—';

  return (
    <div className="min-h-screen pt-32 pb-20 px-4">
      <div className="container mx-auto max-w-7xl space-y-12">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="rounded-[32px] border border-white/10 bg-black/60 p-10 backdrop-blur-xl">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <p className="text-sm uppercase tracking-[0.4em] text-gray-500">Mission control</p>
              <h1 className="text-5xl md:text-6xl font-semibold text-gradient">Live systems dashboard</h1>
              <p className="mt-4 text-lg text-gray-300 max-w-2xl">
                Same telemetry core contributors watch daily: health checks, validator status, latest blocks, and sprint roadmap pulled straight from the Quantum Leap runbooks.
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              {missionMetrics.map((metric) => (
                <div key={metric.label} className="rounded-2xl border border-white/10 bg-white/5 p-5">
                  <metric.icon className="h-6 w-6 text-zion-gold" />
                  <p className="mt-3 text-xs uppercase tracking-[0.3em] text-gray-400">{metric.label}</p>
                  <p className="text-3xl font-semibold text-white">{metric.value}</p>
                  <p className="text-sm text-gray-300">{metric.description}</p>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        <div className="grid gap-6 lg:grid-cols-2">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="rounded-[28px] border border-white/10 bg-black/50 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Activity className={`w-6 h-6 ${
                  health?.status === 'ok' || health?.status === 'healthy'
                    ? 'text-emerald-400'
                    : health?.status === 'degraded'
                    ? 'text-yellow-400 animate-pulse'
                    : 'text-red-400'
                }`} />
                <div>
                  <h2 className="text-2xl font-semibold text-white">System health</h2>
                  <p className="text-sm text-gray-400">RPC · pool · orchestrator · observability</p>
                </div>
              </div>
              <Link href="http://www.zionterranova.com:8001/health" target="_blank" rel="noreferrer" className="text-xs uppercase tracking-[0.3em] text-zion-cyan inline-flex items-center gap-1">
                View API
                <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
            <div className="mt-6 grid grid-cols-2 gap-4">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                <p className="text-xs uppercase tracking-[0.3em] text-gray-400">Status</p>
                <p className="mt-2 text-2xl font-semibold text-white">{health?.status || 'unknown'}</p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                <p className="text-xs uppercase tracking-[0.3em] text-gray-400">Version</p>
                <p className="mt-2 text-2xl font-semibold text-white">{health?.version || 'v2.9.0'}</p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                <p className="text-xs uppercase tracking-[0.3em] text-gray-400">Uptime</p>
                <p className="mt-2 text-2xl font-semibold text-white">{computedUptime}</p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                <p className="text-xs uppercase tracking-[0.3em] text-gray-400">Dependencies</p>
                <div className="mt-2 space-y-1 text-sm text-gray-300">
                  <p>
                    <span className={health?.dependencies?.rpc_node?.healthy ? 'text-emerald-400' : 'text-red-400'}>
                      {health?.dependencies?.rpc_node?.healthy ? '●' : '○'}
                    </span>{' '}
                    RPC Node
                  </p>
                  <p>
                    <span className={health?.dependencies?.mining_pool?.healthy ? 'text-emerald-400' : 'text-red-400'}>
                      {health?.dependencies?.mining_pool?.healthy ? '●' : '○'}
                    </span>{' '}
                    Mining Pool
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="rounded-[28px] border border-white/10 bg-black/50 p-6">
            <div className="flex items-center gap-3 mb-4">
              <TrendingUp className="w-6 h-6 text-zion-gold" />
              <h2 className="text-2xl font-semibold text-white">Chain vitals</h2>
              {!stats && <span className="text-xs text-yellow-400">API offline</span>}
            </div>
            {stats ? (
              <div className="space-y-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <MetricCard label="Blocks" value={stats.total_blocks?.toLocaleString() || '—'} />
                  <MetricCard label="Total supply" value={stats.total_supply ? `${(stats.total_supply / 1e9).toFixed(2)}B` : '—'} />
                  <MetricCard label="Transactions" value={stats.total_transactions?.toLocaleString() || '—'} />
                  <MetricCard label="Difficulty" value={stats.difficulty || '—'} />
                </div>
                {stats.latest_block && (
                  <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                    <p className="text-xs uppercase tracking-[0.3em] text-gray-400">Latest block</p>
                    <div className="mt-3 grid gap-3 text-sm">
                      <div className="flex justify-between text-gray-300">
                        <span>Height</span>
                        <span className="font-mono">{stats.latest_block.height}</span>
                      </div>
                      <div className="flex justify-between text-gray-300">
                        <span>Hash</span>
                        <span className="font-mono text-xs">{stats.latest_block.hash.substring(0, 18)}...</span>
                      </div>
                      <div className="flex justify-between text-gray-300">
                        <span>Timestamp</span>
                        <span>{new Date(stats.latest_block.timestamp * 1000).toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-gray-400 text-center py-12">Awaiting blockchain metrics…</div>
            )}
          </motion.div>
        </div>

        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="rounded-[28px] border border-white/10 bg-white/5 p-6">
          <div className="flex items-center gap-3 mb-4">
            <Cpu className="w-6 h-6 text-zion-gold" />
            <h2 className="text-2xl font-semibold text-white">Recent blocks</h2>
          </div>
          {blocks && blocks.length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2">
              {blocks.map((block: any) => (
                <div key={block.hash} className="rounded-2xl border border-white/10 bg-black/30 p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs uppercase tracking-[0.3em] text-gray-400">#{block.height}</p>
                      <p className="font-mono text-xs text-zion-cyan">{block.hash?.substring(0, 16)}...</p>
                    </div>
                    <span className="text-xs text-gray-400">{new Date(block.timestamp * 1000).toLocaleTimeString()}</span>
                  </div>
                  <div className="mt-3 flex justify-between text-xs text-gray-400">
                    <span>Txs {block.transactions || 0}</span>
                    {block.consciousness_level && <span>{block.consciousness_level}</span>}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center text-gray-400 py-12">No block feed detected from API.</div>
          )}
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="rounded-[32px] border border-zion-gold/30 bg-linear-to-r from-zion-purple/20 via-zion-gold/10 to-zion-cyan/20 p-8">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.4em] text-gray-200">What&apos;s next</p>
              <h2 className="text-3xl font-semibold text-white">Operational roadmap</h2>
              <p className="text-sm text-gray-100 max-w-xl mt-2">Pulled directly from docs/roadmaps and FINAL_REPORT_v2.9.0_SESSION.</p>
            </div>
            <Link href="/roadmap" className="inline-flex items-center gap-2 rounded-2xl bg-black/60 px-5 py-2 text-sm font-semibold text-white">
              Open roadmap
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            {roadmapSlices.map((slice) => (
              <div key={slice.title} className="rounded-2xl border border-white/20 bg-black/30 p-4">
                <p className="text-xs uppercase tracking-[0.3em] text-gray-400">Sprint</p>
                <h3 className="mt-2 text-lg font-semibold text-white">{slice.title}</h3>
                <ul className="mt-3 space-y-2 text-sm text-gray-200">
                  {slice.bullets.map((item) => (
                    <li key={item} className="flex items-start gap-2">
                      <ArrowRight className="h-3 w-3 text-zion-gold mt-1" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}

function MetricCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
      <p className="text-xs uppercase tracking-[0.3em] text-gray-400">{label}</p>
      <p className="mt-2 text-2xl font-semibold text-white">{value}</p>
    </div>
  );
}
