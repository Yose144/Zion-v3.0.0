'use client';

import { motion } from 'framer-motion';
import { ArrowRight, CalendarDays, CheckCircle2, Rocket, Target } from 'lucide-react';
import Link from 'next/link';

const phaseCards = [
  {
    name: 'Security Hardening Sprint',
    window: 'Dec 1 – Dec 15, 2025',
    progress: 30,
    highlights: [
      'ecdsa → cryptography migration + regression tests',
      'Ledger & Trezor signing flows wired end-to-end',
      'Trail of Bits audit + bug bounty kickoff',
    ],
  },
  {
    name: 'Performance Optimization Sprint',
    window: 'Dec 16 – Dec 25, 2025',
    progress: 20,
    highlights: [
      'SQLite WAL + indexes with telemetry',
      'Redis caching (80%+ hit goal) + compact blocks',
      'Benchmark suite for miners/pool/API latency',
    ],
  },
  {
    name: 'Native Dirigent Build',
    window: 'Q1 – Q4 2025/26',
    progress: 5,
    highlights: [
      'Rust/Tokio pool + LMDB core prototypes',
      'libp2p networking + cargo test/fuzz gates',
      'HAProxy feature flags for gradual rollout',
    ],
  },
];

const timeline = [
  {
    title: 'Weeks 1-2 · Nov 13 – Nov 26',
    focus: 'Universal miner integration + bridge load tests',
  },
  {
    title: 'Weeks 3-4 · Nov 27 – Dec 10',
    focus: 'Validator dashboard UI + documentation blitz',
  },
  {
    title: 'Security Sprint · Dec 1 – Dec 15',
    focus: 'Cryptography migration, hardware wallets, audit warmups',
  },
  {
    title: 'Performance Sprint · Dec 16 – Dec 25',
    focus: 'SQLite WAL, Redis caching, benchmark publication',
  },
];

export default function RoadmapPulse() {
  return (
    <section className="py-24 px-4">
      <div className="container mx-auto space-y-12">
        <div className="flex flex-col lg:flex-row lg:items-center gap-6">
          <div className="flex-1 space-y-3">
            <p className="text-sm uppercase tracking-[0.4em] text-zion-gold">Roadmap</p>
            <h2 className="text-4xl md:text-5xl font-bold text-white">
              Quantum Leap <span className="text-gradient">flight plan → Native Dirigent</span>
            </h2>
            <p className="text-lg text-gray-300 max-w-2xl">
              Snapshot of the security, performance, and native rewrite phases now that ML + WARP are locked.
              Every line item maps to docs/roadmaps and the live `/roadmap` hub feeding supporters.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link
              href="/roadmap"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-2xl bg-linear-to-r from-zion-gold via-zion-purple to-zion-cyan text-lg font-semibold"
            >
              Full Roadmap
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link
              href="/reports"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-2xl border border-white/10 bg-white/5 text-lg font-semibold"
            >
              <CalendarDays className="w-5 h-5 text-zion-cyan" />
              Status Reports
            </Link>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {phaseCards.map((phase, idx) => (
            <motion.div
              key={phase.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.45, delay: idx * 0.05 }}
              className="rounded-3xl border border-white/10 bg-black/50 p-6 space-y-4 backdrop-blur"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs uppercase tracking-[0.4em] text-gray-400">{phase.window}</p>
                  <h3 className="text-xl font-semibold text-white">{phase.name}</h3>
                </div>
                <div className="px-3 py-1 text-xs font-semibold text-zion-gold bg-zion-gold/10 rounded-full">
                  {phase.progress}%
                </div>
              </div>
              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: `${phase.progress}%` }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: 0.2 + idx * 0.05 }}
                  className="h-full bg-linear-to-r from-zion-gold via-zion-purple to-zion-cyan"
                />
              </div>
              <ul className="space-y-2 text-sm text-gray-300">
                {phase.highlights.map((item) => (
                  <li key={item} className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-zion-cyan mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="rounded-3xl border border-white/10 bg-white/5 p-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <Rocket className="w-6 h-6 text-zion-cyan" />
            <div>
              <p className="text-xs uppercase tracking-[0.4em] text-gray-400">Sprint Timeline</p>
              <h3 className="text-2xl font-semibold text-white">30-day execution tapes</h3>
            </div>
          </div>

          <div className="grid md:grid-cols-4 gap-4">
            {timeline.map((entry, idx) => (
              <div key={entry.title} className="rounded-2xl border border-white/10 bg-black/40 p-4">
                <p className="text-xs uppercase tracking-[0.3em] text-gray-400">{entry.title}</p>
                <p className="text-sm text-gray-200 mt-3 leading-relaxed">{entry.focus}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
