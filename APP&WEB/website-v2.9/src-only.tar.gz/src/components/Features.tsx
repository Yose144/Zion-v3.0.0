'use client';

import { motion } from 'framer-motion';
import { Brain, Cpu, Landmark, Rocket, Shield, Sparkles, Zap } from 'lucide-react';

const continuumTracks = [
  {
    title: 'AI Warp Engine',
    description: '32-model afterburner with conscious prompt weighting and automatic miner retargeting.',
    icon: Brain,
    badge: 'Neuro Fusion',
    spectrum: 'from-zion-cyan/20 via-zion-purple/10 to-transparent',
  },
  {
    title: 'Sacred Miner Fleet',
    description: 'Native Cosmic Harmony, RandomX, Yescrypt cores compiled with vector quantization for macOS, Linux, and Windows.',
    icon: Cpu,
    badge: '548k H/s',
    spectrum: 'from-zion-gold/20 via-orange-500/10 to-transparent',
  },
  {
    title: 'DAO Orbit Council',
    description: 'On-chain rituals for treasury unlocks and WARP-corridor approvals with 11 seat holographic voting.',
    icon: Landmark,
    badge: 'Council v3',
    spectrum: 'from-rose-500/20 via-zion-purple/10 to-transparent',
  },
  {
    title: 'WARP Liquidity Corridors',
    description: '11 cross-chain lanes (ETH, SOL, XLM, ADA, BSC, Polygon, Cosmos, NEAR, TON, XRPL, Avalanche) with adaptive fees.',
    icon: Rocket,
    badge: '11 lanes',
    spectrum: 'from-emerald-500/20 via-zion-cyan/10 to-transparent',
  },
  {
    title: 'Sentinel Mesh Security',
    description: 'Matrix-grade anomaly detection, Prometheus telemetry, and real-time failover orchestrated via Redis streams.',
    icon: Shield,
    badge: 'Guardian',
    spectrum: 'from-blue-500/20 via-cyan-400/10 to-transparent',
  },
  {
    title: 'Consciousness Mining',
    description: 'Seven-dimension proof-of-consciousness curve aligning Physical → Divine states to dynamic block rewards.',
    icon: Sparkles,
    badge: 'Sacred 7',
    spectrum: 'from-violet-500/20 via-fuchsia-400/10 to-transparent',
  },
];

const timeline = [
  { phase: 'Phase 6 · Now', detail: 'Quantum Leap release, observatory UI, AI afterburner unification.' },
  { phase: 'Phase 7 · Incoming', detail: 'Bio-AI co-mining, DAO liquidity anchors, universal miner UX.' },
  { phase: 'Phase 8 · Planned', detail: 'Interstellar mesh, on-chain dreamstate proofs, cosmic identity passports.' },
];

export default function Features() {
  return (
    <section className="py-24 px-4">
      <div className="container mx-auto space-y-12">
        <div className="flex flex-col lg:flex-row lg:items-end gap-6">
          <div className="flex-1">
            <p className="text-sm uppercase tracking-[0.4em] text-gray-400">Continuum</p>
            <h2 className="text-4xl md:text-5xl font-bold text-white">
              Pillars of the <span className="text-gradient">ZION Quantum Stack</span>
            </h2>
          </div>
          <p className="text-lg text-gray-300 max-w-2xl">
            Every pillar links miners, AI pilots, and DAO guardians. Pick any lane to dive into docs,
            production configs, and live orchestration scripts.
          </p>
        </div>

        <div className="grid lg:grid-cols-[1.1fr_0.9fr] gap-10">
          <div className="grid sm:grid-cols-2 gap-6">
            {continuumTracks.map((track, index) => (
              <motion.div
                key={track.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                className={`rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur hover:border-white/30 transition relative overflow-hidden`}
              >
                <div className={`absolute inset-0 bg-linear-to-br ${track.spectrum} opacity-70 pointer-events-none`} />
                <div className="relative space-y-3">
                  <div className="flex items-center justify-between">
                    <track.icon className="w-6 h-6 text-white" />
                    <span className="text-xs font-semibold tracking-wide text-zion-gold bg-zion-gold/10 rounded-full px-3 py-1">
                      {track.badge}
                    </span>
                  </div>
                  <h3 className="text-xl font-semibold text-white">{track.title}</h3>
                  <p className="text-sm text-gray-200 leading-relaxed">{track.description}</p>
                </div>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="rounded-[32px] border border-white/10 bg-black/50 backdrop-blur-xl p-8 space-y-6"
          >
            <div className="flex items-center gap-3 text-sm text-gray-400">
              <Zap className="w-5 h-5 text-zion-gold" />
              Quantum Evolution Timeline
            </div>

            <div className="space-y-5">
              {timeline.map((item) => (
                <div key={item.phase} className="rounded-2xl border border-white/10 p-5">
                  <p className="text-xs uppercase tracking-[0.3em] text-gray-400">{item.phase}</p>
                  <p className="text-base text-white mt-2">{item.detail}</p>
                </div>
              ))}
            </div>

            <div className="rounded-2xl border border-white/10 bg-linear-to-br from-zion-purple/20 to-zion-cyan/10 p-6 text-gray-100 text-sm">
              Guardian councils meet weekly inside the Galactic Core observatory. Request access via
              DAO portal to propose a lane, hardware bounty, or AI ritual.
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
