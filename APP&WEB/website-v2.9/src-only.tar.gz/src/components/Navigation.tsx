'use client';

import Link from 'next/link';
import Image from 'next/image';
import { useState, useEffect } from 'react';
import { usePathname } from 'next/navigation';
import { Menu, X, SignalHigh, Sparkles, Orbit, ArrowUpRight, ChevronDown } from 'lucide-react';
import { useObservatory } from '@/contexts/ObservatoryContext';

const navGroups = [
  {
    title: 'Mission',
    items: [
      { href: '/', label: 'Home' },
      { href: '/dashboard', label: 'Dashboard' },
      { href: '/roadmap', label: 'Roadmap' },
    ],
  },
  {
    title: 'Stacks',
    items: [
      { href: '/warp', label: 'Warp' },
      { href: '/dao', label: 'DAO' },
      { href: '/download', label: 'Download' },
      { href: '/mining', label: 'Mining' },
    ],
  },
  {
    title: 'Knowledge',
    items: [
      { href: '/docs', label: 'Docs' },
      { href: '/api-reference', label: 'API' },
    ],
  },
];

const modeBadges = {
  'deep-space': { label: 'Deep Space', accent: 'text-zion-gold' },
  'planet-orbit': { label: 'Planet Orbit', accent: 'text-zion-cyan' },
  'galactic-core': { label: 'Galactic Core', accent: 'text-zion-purple' },
};

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [openGroup, setOpenGroup] = useState<string | null>(null);
  const pathname = usePathname();
  const { mode } = useObservatory();
  const badge = modeBadges[mode] ?? modeBadges['deep-space'];
  const activeGroup = navGroups.find((group) => group.title === openGroup);

  // Zavře desktop dropdown při kliku mimo
  useEffect(() => {
    const handleClick = (event: MouseEvent | MouseEventInit | any) => {
      const target = event.target as HTMLElement | null;
      if (!target) return;
      if (!target.closest('[data-nav-desktop]')) {
        setOpenGroup(null);
      }
    };
    if (openGroup) {
      document.addEventListener('click', handleClick);
    }
    return () => {
      document.removeEventListener('click', handleClick);
    };
  }, [openGroup]);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50">
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-zion-purple/30 via-transparent to-zion-cyan/30 blur-3xl opacity-40" />
      <div className="container mx-auto px-4 py-4 relative">
        <div className="flex items-center justify-between rounded-3xl border border-white/10 bg-black/60 backdrop-blur-xl px-4 py-3 shadow-[0_20px_60px_rgba(0,0,0,0.45)]">
          <Link href="/" className="flex items-center space-x-3 group">
            <div className="w-12 h-12 rounded-lg flex items-center justify-center relative overflow-hidden border border-white/20 group-hover:border-zion-gold/50 transition-colors bg-black/40">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(255,215,0,0.3),transparent_60%)]" />
              <Image 
                src="/Z.gif" 
                alt="ZION Logo" 
                width={40} 
                height={40}
                className="relative z-10"
                unoptimized
              />
            </div>
            <span className="text-2xl font-bold text-gradient tracking-tight">ZION</span>
            <span className="text-[11px] px-2 py-1 rounded bg-white/5 border border-white/10 uppercase tracking-widest">
              2.9 &ldquo;Quantum Leap&rdquo;
            </span>
          </Link>

          <div className="hidden md:flex items-center gap-6" data-nav-desktop>
            <div className="relative">
              <div className="flex items-center gap-2">
                {navGroups.map((group) => {
                  const isActive = openGroup === group.title;
                  return (
                    <button
                      key={group.title}
                      type="button"
                      onClick={() => setOpenGroup(isActive ? null : group.title)}
                      className={`inline-flex items-center gap-1 rounded-2xl border border-white/10 px-3 py-2 text-xs font-semibold uppercase tracking-[0.3em] transition-colors ${
                        isActive ? 'bg-white/10 text-white' : 'text-gray-400 hover:text-white'
                      }`}
                      aria-expanded={isActive}
                    >
                      {group.title}
                      <ChevronDown className={`h-3 w-3 transition-transform ${isActive ? 'rotate-180' : ''}`} />
                    </button>
                  );
                })}
              </div>
              {activeGroup && (
                <div className="absolute right-0 mt-3 w-72 rounded-3xl border border-white/10 bg-black/80 p-4 shadow-[0_15px_45px_rgba(0,0,0,0.45)] backdrop-blur-xl">
                  <p className="text-[10px] uppercase tracking-[0.4em] text-gray-500">{activeGroup.title}</p>
                  <div className="mt-3 flex flex-col gap-2">
                    {activeGroup.items.map((item) => (
                      <Link
                        key={item.href}
                        href={item.href}
                        className={`rounded-2xl px-4 py-3 text-sm font-semibold transition ${
                          pathname === item.href ? 'bg-white/10 text-white' : 'text-gray-300 hover:bg-white/5'
                        }`}
                        onClick={() => setOpenGroup(null)}
                      >
                        {item.label}
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <a
              href="http://www.zionterranova.com:8001/health"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-2 text-xs font-semibold rounded-xl border border-white/20 hover:border-zion-gold/50 bg-black/30 backdrop-blur transition-colors inline-flex items-center gap-2"
            >
              <SignalHigh className="w-3 h-3 text-zion-gold" /> API Health
            </a>
            <Link
              href="/dashboard"
              className="inline-flex items-center gap-2 rounded-2xl bg-linear-to-r from-zion-gold via-zion-purple to-zion-cyan px-4 py-2 text-xs font-semibold uppercase tracking-wider shadow-[0_10px_30px_rgba(147,51,234,0.35)]"
            >
              Dashboard
              <ArrowUpRight className="w-4 h-4" />
            </Link>
          </div>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden text-white p-2 rounded border border-white/20"
          >
            {isOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        <div className="mt-3 flex items-center justify-between text-xs text-gray-400">
          <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1">
            <Sparkles className="w-3 h-3 text-zion-gold" />
            <span>Observatory</span>
            <span className={`font-semibold ${badge.accent}`}>{badge.label}</span>
          </div>
          <div className="inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.3em] text-gray-500">
            <Orbit className="w-3 h-3 text-zion-cyan" />
            WARP STATUS · Online
          </div>
        </div>

        {isOpen && (
          <div className="md:hidden mt-4 pb-4 space-y-3 rounded-2xl border border-white/10 bg-black/70 px-4 py-4">
            {navGroups.map((group) => (
              <div key={group.title}>
                <p className="text-[10px] uppercase tracking-[0.4em] text-gray-500 mb-1">{group.title}</p>
                {group.items.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`block rounded-xl px-3 py-2 text-sm font-semibold transition ${
                      pathname === item.href ? 'bg-white/10 text-white' : 'text-gray-300 hover:bg-white/5'
                    }`}
                    onClick={() => setIsOpen(false)}
                  >
                    {item.label}
                  </Link>
                ))}
              </div>
            ))}
            <div className="h-px w-full bg-white/10" />
            <div className="grid grid-cols-2 gap-3 text-xs">
              <a
                href="http://www.zionterranova.com:8001/health"
                target="_blank"
                rel="noopener noreferrer"
                className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 inline-flex items-center gap-2"
              >
                <SignalHigh className="w-3 h-3 text-zion-gold" /> API Health
              </a>
              <Link
                href="/dashboard"
                onClick={() => setIsOpen(false)}
                className="rounded-xl bg-linear-to-r from-zion-gold via-zion-purple to-zion-cyan px-3 py-2 inline-flex items-center gap-2 text-white"
              >
                Dashboard
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
