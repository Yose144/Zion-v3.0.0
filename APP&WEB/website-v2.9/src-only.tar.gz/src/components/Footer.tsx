import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-black/90 border-t border-zion-gold/20 py-12 mt-20">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold text-gradient mb-4">ZION</h3>
            <p className="text-gray-400 text-sm">
              Multi-dimensional blockchain with consciousness-based mining and sacred geometry protocols.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Resources</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/docs" className="text-gray-400 hover:text-zion-gold">Documentation</Link></li>
              <li><Link href="/roadmap" className="text-gray-400 hover:text-zion-gold">Roadmap</Link></li>
              <li><Link href="/dashboard" className="text-gray-400 hover:text-zion-gold">Dashboard</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Developer</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="http://www.zionterranova.com:8001/docs" className="text-gray-400 hover:text-zion-gold">API Docs</a></li>
              <li><a href="https://github.com/Yose144/Zion-2.9" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-zion-gold">GitHub</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Network</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>RPC: :8545</li>
              <li>Pool: :3333</li>
              <li>API: :8001</li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-gray-800 text-center text-sm text-gray-500">
          © 2025 ZION Blockchain. Conscious Mining Revolution.
        </div>
      </div>
    </footer>
  );
}
