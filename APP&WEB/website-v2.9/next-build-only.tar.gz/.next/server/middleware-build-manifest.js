globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/17d89befc11a9443.js",
    "static/chunks/52f2f12e720ddff4.js",
    "static/chunks/89d2b97ece5ec868.js",
    "static/chunks/3210b7d6f2dc6a21.js",
    "static/chunks/turbopack-326d31c257ccc19f.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];