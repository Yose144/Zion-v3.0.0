module.exports=[29016,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_mining_page_actions_b28b5891.js.map