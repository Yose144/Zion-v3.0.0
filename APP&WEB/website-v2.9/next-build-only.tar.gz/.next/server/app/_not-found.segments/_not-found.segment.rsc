1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/96cd6c9695287349.js","/_next/static/chunks/c81db6e24f0cfdeb.js","/_next/static/chunks/6c744c5df5b102cc.js","/_next/static/chunks/6f0e4d2e914049fd.js"],"default"]
3:I[37457,["/_next/static/chunks/96cd6c9695287349.js","/_next/static/chunks/c81db6e24f0cfdeb.js","/_next/static/chunks/6c744c5df5b102cc.js","/_next/static/chunks/6f0e4d2e914049fd.js"],"default"]
0:{"buildId":"qqoMffPMP3vRrPOHfv8VB","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
