1:"$Sreact.fragment"
2:I[63269,["/_next/static/chunks/96cd6c9695287349.js","/_next/static/chunks/6c744c5df5b102cc.js","/_next/static/chunks/6f0e4d2e914049fd.js","/_next/static/chunks/4e86df801d862687.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/c81db6e24f0cfdeb.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"qqoMffPMP3vRrPOHfv8VB","rsc":["$","$1","c",{"children":[["$","$L2",null,{"stats":null,"health":{"status":"unknown","version":"v2.8.9","uptime":0},"blocks":[]}],[["$","script","script-0",{"src":"/_next/static/chunks/4e86df801d862687.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
