(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/Navigation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Navigation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/menu.js [app-client] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const navItems = [
    {
        href: '/',
        label: 'Home'
    },
    {
        href: '/dashboard',
        label: 'Dashboard'
    },
    {
        href: '/mining',
        label: 'Mining'
    },
    {
        href: '/docs',
        label: 'Docs'
    },
    {
        href: '/roadmap',
        label: 'Roadmap'
    }
];
function Navigation() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(15);
    if ($[0] !== "34cd73268fd35abf9002942e4ce07ba88c297e241e51e8bb5e97864015b67381") {
        for(let $i = 0; $i < 15; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "34cd73268fd35abf9002942e4ce07ba88c297e241e51e8bb5e97864015b67381";
    }
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: "/",
            className: "flex items-center space-x-3 group",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-12 h-12 rounded-lg flex items-center justify-center relative overflow-hidden border border-white/20 group-hover:border-zion-gold/50 transition-colors bg-black/40",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(255,215,0,0.3),transparent_60%)]"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Navigation.tsx",
                            lineNumber: 35,
                            columnNumber: 252
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: "/Z.gif",
                            alt: "ZION Logo",
                            width: 40,
                            height: 40,
                            className: "relative z-10",
                            unoptimized: true
                        }, void 0, false, {
                            fileName: "[project]/src/components/Navigation.tsx",
                            lineNumber: 35,
                            columnNumber: 364
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Navigation.tsx",
                    lineNumber: 35,
                    columnNumber: 71
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-2xl font-bold text-gradient tracking-tight",
                    children: "ZION"
                }, void 0, false, {
                    fileName: "[project]/src/components/Navigation.tsx",
                    lineNumber: 35,
                    columnNumber: 476
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-[11px] px-2 py-1 rounded bg-white/5 border border-white/10 uppercase",
                    children: "2.9 “Quantum Leap”"
                }, void 0, false, {
                    fileName: "[project]/src/components/Navigation.tsx",
                    lineNumber: 35,
                    columnNumber: 553
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Navigation.tsx",
            lineNumber: 35,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "hidden md:flex items-center space-x-6",
            children: [
                navItems.map(_NavigationNavItemsMap),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    href: "http://www.zionterranova.com:8001/health",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className: "px-3 py-2 text-xs font-semibold rounded border border-white/20 hover:border-zion-gold/50 bg-black/30 backdrop-blur transition-colors",
                    children: "API"
                }, void 0, false, {
                    fileName: "[project]/src/components/Navigation.tsx",
                    lineNumber: 42,
                    columnNumber: 103
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Navigation.tsx",
            lineNumber: 42,
            columnNumber: 10
        }, this);
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] !== isOpen) {
        t2 = ({
            "Navigation[<button>.onClick]": ()=>setIsOpen(!isOpen)
        })["Navigation[<button>.onClick]"];
        $[3] = isOpen;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    let t3;
    if ($[5] !== isOpen) {
        t3 = isOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
            size: 20
        }, void 0, false, {
            fileName: "[project]/src/components/Navigation.tsx",
            lineNumber: 59,
            columnNumber: 19
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
            size: 20
        }, void 0, false, {
            fileName: "[project]/src/components/Navigation.tsx",
            lineNumber: 59,
            columnNumber: 37
        }, this);
        $[5] = isOpen;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] !== t2 || $[8] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-between",
            children: [
                t0,
                t1,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: t2,
                    className: "md:hidden text-white p-2 rounded border border-white/20",
                    children: t3
                }, void 0, false, {
                    fileName: "[project]/src/components/Navigation.tsx",
                    lineNumber: 67,
                    columnNumber: 69
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Navigation.tsx",
            lineNumber: 67,
            columnNumber: 10
        }, this);
        $[7] = t2;
        $[8] = t3;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    let t5;
    if ($[10] !== isOpen) {
        t5 = isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "md:hidden mt-4 pb-4 space-y-4",
            children: navItems.map({
                "Navigation[navItems.map()]": (item_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: item_0.href,
                        className: "block text-gray-300 hover:text-zion-gold transition-colors",
                        onClick: {
                            "Navigation[navItems.map() > <Link>.onClick]": ()=>setIsOpen(false)
                        }["Navigation[navItems.map() > <Link>.onClick]"],
                        children: item_0.label
                    }, item_0.href, false, {
                        fileName: "[project]/src/components/Navigation.tsx",
                        lineNumber: 77,
                        columnNumber: 49
                    }, this)
            }["Navigation[navItems.map()]"])
        }, void 0, false, {
            fileName: "[project]/src/components/Navigation.tsx",
            lineNumber: 76,
            columnNumber: 20
        }, this);
        $[10] = isOpen;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    let t6;
    if ($[12] !== t4 || $[13] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
            className: "fixed top-0 left-0 right-0 z-50 bg-black/70 backdrop-blur-md border-b border-white/10 neon-border",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4 py-4",
                children: [
                    t4,
                    t5
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Navigation.tsx",
                lineNumber: 88,
                columnNumber: 125
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Navigation.tsx",
            lineNumber: 88,
            columnNumber: 10
        }, this);
        $[12] = t4;
        $[13] = t5;
        $[14] = t6;
    } else {
        t6 = $[14];
    }
    return t6;
}
_s(Navigation, "+sus0Lb0ewKHdwiUhiTAJFoFyQ0=");
_c = Navigation;
function _NavigationNavItemsMap(item) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: item.href,
        className: "text-gray-300 hover:text-zion-gold transition-colors duration-200 text-sm font-medium tracking-wide",
        children: item.label
    }, item.href, false, {
        fileName: "[project]/src/components/Navigation.tsx",
        lineNumber: 98,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "Navigation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/contexts/ThemeContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThemeProvider",
    ()=>ThemeProvider,
    "useTheme",
    ()=>useTheme
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
const themes = {
    cosmic: {
        name: 'cosmic',
        displayName: 'Cosmic (Default)',
        colors: {
            primary: '#FFD700',
            // Gold
            secondary: '#9333EA',
            // Purple
            accent: '#06B6D4',
            // Cyan
            background: '#0a0118',
            text: '#e0e0e0'
        },
        fonts: {
            heading: 'Inter, sans-serif',
            body: 'Inter, sans-serif',
            mono: 'monospace'
        }
    },
    matrix: {
        name: 'matrix',
        displayName: 'Matrix Code',
        colors: {
            primary: '#00ff41',
            // Matrix Green
            secondary: '#00eaff',
            // Cyan
            accent: '#ff2dfb',
            // Magenta
            background: '#0d0208',
            text: '#e0e0e0'
        },
        fonts: {
            heading: 'Orbitron, sans-serif',
            body: 'Share Tech Mono, monospace',
            mono: 'Share Tech Mono, monospace'
        }
    },
    cyberpunk: {
        name: 'cyberpunk',
        displayName: 'Cyberpunk 2077',
        colors: {
            primary: '#fcee09',
            // Yellow
            secondary: '#00f0ff',
            // Cyan
            accent: '#ff006e',
            // Hot Pink
            background: '#0a0a0a',
            text: '#f0f0f0'
        },
        fonts: {
            heading: 'Rajdhani, sans-serif',
            body: 'Rajdhani, sans-serif',
            mono: 'Courier New, monospace'
        }
    },
    sacred: {
        name: 'sacred',
        displayName: 'Sacred Geometry',
        colors: {
            primary: '#d4af37',
            // Ancient Gold
            secondary: '#4a148c',
            // Deep Purple
            accent: '#00897b',
            // Teal
            background: '#1a1a2e',
            text: '#f5f5f5'
        },
        fonts: {
            heading: 'Cinzel, serif',
            body: 'Lora, serif',
            mono: 'monospace'
        }
    }
};
const ThemeContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function getStoredTheme() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const savedTheme = localStorage.getItem('zion-theme');
    if (savedTheme && themes[savedTheme]) {
        return themes[savedTheme];
    }
    return themes.cosmic;
}
function ThemeProvider(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(22);
    if ($[0] !== "9bd12bcb5b6642de3c347464866e60d31253e7e7603a0daa0b1b24dd570efb6f") {
        for(let $i = 0; $i < 22; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9bd12bcb5b6642de3c347464866e60d31253e7e7603a0daa0b1b24dd570efb6f";
    }
    const { children } = t0;
    const [currentTheme, setCurrentTheme] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(_ThemeProviderUseState);
    let t1;
    if ($[1] !== currentTheme.colors.accent || $[2] !== currentTheme.colors.background || $[3] !== currentTheme.colors.primary || $[4] !== currentTheme.colors.secondary || $[5] !== currentTheme.colors.text || $[6] !== currentTheme.fonts.body || $[7] !== currentTheme.fonts.heading || $[8] !== currentTheme.fonts.mono) {
        t1 = ({
            "ThemeProvider[useEffect()]": ()=>{
                const root = document.documentElement;
                root.style.setProperty("--color-primary", currentTheme.colors.primary);
                root.style.setProperty("--color-secondary", currentTheme.colors.secondary);
                root.style.setProperty("--color-accent", currentTheme.colors.accent);
                root.style.setProperty("--color-background", currentTheme.colors.background);
                root.style.setProperty("--color-text", currentTheme.colors.text);
                root.style.setProperty("--font-heading", currentTheme.fonts.heading);
                root.style.setProperty("--font-body", currentTheme.fonts.body);
                root.style.setProperty("--font-mono", currentTheme.fonts.mono);
                document.body.style.background = currentTheme.colors.background;
                document.body.style.color = currentTheme.colors.text;
            }
        })["ThemeProvider[useEffect()]"];
        $[1] = currentTheme.colors.accent;
        $[2] = currentTheme.colors.background;
        $[3] = currentTheme.colors.primary;
        $[4] = currentTheme.colors.secondary;
        $[5] = currentTheme.colors.text;
        $[6] = currentTheme.fonts.body;
        $[7] = currentTheme.fonts.heading;
        $[8] = currentTheme.fonts.mono;
        $[9] = t1;
    } else {
        t1 = $[9];
    }
    let t2;
    if ($[10] !== currentTheme) {
        t2 = [
            currentTheme
        ];
        $[10] = currentTheme;
        $[11] = t2;
    } else {
        t2 = $[11];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    let t4;
    if ($[12] !== currentTheme.name) {
        t3 = ({
            "ThemeProvider[useEffect()]": ()=>{
                localStorage.setItem("zion-theme", currentTheme.name);
            }
        })["ThemeProvider[useEffect()]"];
        t4 = [
            currentTheme.name
        ];
        $[12] = currentTheme.name;
        $[13] = t3;
        $[14] = t4;
    } else {
        t3 = $[13];
        t4 = $[14];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t3, t4);
    let t5;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = ({
            "ThemeProvider[setTheme]": (themeName)=>{
                const theme = themes[themeName];
                if (theme) {
                    setCurrentTheme(theme);
                }
            }
        })["ThemeProvider[setTheme]"];
        $[15] = t5;
    } else {
        t5 = $[15];
    }
    const setTheme = t5;
    let t6;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = Object.values(themes);
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    let t7;
    if ($[17] !== currentTheme) {
        t7 = {
            currentTheme,
            setTheme,
            availableThemes: t6
        };
        $[17] = currentTheme;
        $[18] = t7;
    } else {
        t7 = $[18];
    }
    let t8;
    if ($[19] !== children || $[20] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ThemeContext.Provider, {
            value: t7,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/contexts/ThemeContext.tsx",
            lineNumber: 219,
            columnNumber: 10
        }, this);
        $[19] = children;
        $[20] = t7;
        $[21] = t8;
    } else {
        t8 = $[21];
    }
    return t8;
}
_s(ThemeProvider, "KVAWh+b3dJ7t69kPKPJr60Op0d0=");
_c = ThemeProvider;
function _ThemeProviderUseState() {
    return getStoredTheme();
}
function useTheme() {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(1);
    if ($[0] !== "9bd12bcb5b6642de3c347464866e60d31253e7e7603a0daa0b1b24dd570efb6f") {
        for(let $i = 0; $i < 1; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9bd12bcb5b6642de3c347464866e60d31253e7e7603a0daa0b1b24dd570efb6f";
    }
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ThemeContext);
    if (!context) {
        throw new Error("useTheme must be used within ThemeProvider");
    }
    return context;
}
_s1(useTheme, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "ThemeProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/contexts/ObservatoryContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ObservatoryProvider",
    ()=>ObservatoryProvider,
    "useObservatory",
    ()=>useObservatory
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
const ObservatoryContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
const MODES = [
    {
        id: "deep-space",
        label: "Deep Space",
        description: "Flight through the cosmos"
    },
    {
        id: "planet-orbit",
        label: "Planet Orbit",
        description: "AI / Mining Observatory"
    },
    {
        id: "galactic-core",
        label: "Galactic Core",
        description: "WARP & DAO view"
    }
];
const STORAGE_KEY = "zion-observatory-mode";
function getStoredMode() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored && MODES.find((m)=>m.id === stored) ? stored : 'deep-space';
}
function ObservatoryProvider(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "dcd103df31f0f4132ec887cf7f78d5d6e3a97478a153a4dc851277b1ac0621a9") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "dcd103df31f0f4132ec887cf7f78d5d6e3a97478a153a4dc851277b1ac0621a9";
    }
    const { children } = t0;
    const [mode, setMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(_ObservatoryProviderUseState);
    let t1;
    let t2;
    if ($[1] !== mode) {
        t1 = ({
            "ObservatoryProvider[useEffect()]": ()=>{
                localStorage.setItem(STORAGE_KEY, mode);
            }
        })["ObservatoryProvider[useEffect()]"];
        t2 = [
            mode
        ];
        $[1] = mode;
        $[2] = t1;
        $[3] = t2;
    } else {
        t1 = $[2];
        t2 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[4] !== mode) {
        t3 = {
            mode,
            setMode,
            availableModes: MODES
        };
        $[4] = mode;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const value = t3;
    let t4;
    if ($[6] !== children || $[7] !== value) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ObservatoryContext.Provider, {
            value: value,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/contexts/ObservatoryContext.tsx",
            lineNumber: 81,
            columnNumber: 10
        }, this);
        $[6] = children;
        $[7] = value;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    return t4;
}
_s(ObservatoryProvider, "IUf4Vgbw+MIaScjBYZOfnf+uFNQ=");
_c = ObservatoryProvider;
function _ObservatoryProviderUseState() {
    return getStoredMode();
}
function useObservatory() {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(1);
    if ($[0] !== "dcd103df31f0f4132ec887cf7f78d5d6e3a97478a153a4dc851277b1ac0621a9") {
        for(let $i = 0; $i < 1; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "dcd103df31f0f4132ec887cf7f78d5d6e3a97478a153a4dc851277b1ac0621a9";
    }
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ObservatoryContext);
    if (!ctx) {
        throw new Error("useObservatory must be used within ObservatoryProvider");
    }
    return ctx;
}
_s1(useObservatory, "/dMy7t63NXD4eYACoT93CePwGrg=");
var _c;
__turbopack_context__.k.register(_c, "ObservatoryProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/StarfieldBackground.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StarfieldBackground
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const DEFAULT_COLOR = [
    255,
    215,
    0
];
const DEFAULT_GRADIENT = 'radial-gradient(ellipse at bottom, #1B2735 0%, #090A0F 100%)';
function StarfieldBackground(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "67b42b9fbc5c5073564c3040cb6037a526837e3243152f66bafba496ff129ade") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "67b42b9fbc5c5073564c3040cb6037a526837e3243152f66bafba496ff129ade";
    }
    const { starColor: t1, density: t2, speed: t3, trailOpacity: t4, backgroundGradient: t5 } = t0;
    const starColor = t1 === undefined ? DEFAULT_COLOR : t1;
    const density = t2 === undefined ? 220 : t2;
    const speed = t3 === undefined ? 2 : t3;
    const trailOpacity = t4 === undefined ? 0.1 : t4;
    const backgroundGradient = t5 === undefined ? DEFAULT_GRADIENT : t5;
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t6;
    let t7;
    if ($[1] !== density || $[2] !== speed || $[3] !== starColor || $[4] !== trailOpacity) {
        t6 = ({
            "StarfieldBackground[useEffect()]": ()=>{
                const canvas = canvasRef.current;
                if (!canvas) {
                    return;
                }
                const ctx = canvas.getContext("2d");
                if (!ctx) {
                    return;
                }
                const stars = [];
                const resize = {
                    "StarfieldBackground[useEffect() > resize]": ()=>{
                        canvas.width = window.innerWidth;
                        canvas.height = window.innerHeight;
                    }
                }["StarfieldBackground[useEffect() > resize]"];
                const seedStars = {
                    "StarfieldBackground[useEffect() > seedStars]": ()=>{
                        stars.splice(0, stars.length);
                        for(let i = 0; i < density; i++){
                            stars.push({
                                x: Math.random() * canvas.width - canvas.width / 2,
                                y: Math.random() * canvas.height - canvas.height / 2,
                                z: Math.random() * canvas.width,
                                size: Math.random() * 2 + 0.5
                            });
                        }
                    }
                }["StarfieldBackground[useEffect() > seedStars]"];
                resize();
                seedStars();
                let animationFrameId;
                const animate = {
                    "StarfieldBackground[useEffect() > animate]": ()=>{
                        if (!ctx || !canvas) {
                            return;
                        }
                        ctx.fillStyle = `rgba(0, 0, 0, ${Math.min(Math.max(trailOpacity, 0.02), 0.3)})`;
                        ctx.fillRect(0, 0, canvas.width, canvas.height);
                        stars.forEach({
                            "StarfieldBackground[useEffect() > animate > stars.forEach()]": (star)=>{
                                star.z = star.z - speed;
                                if (star.z <= 0) {
                                    star.z = canvas.width;
                                    star.x = Math.random() * canvas.width - canvas.width / 2;
                                    star.y = Math.random() * canvas.height - canvas.height / 2;
                                }
                                const x = star.x / star.z * canvas.width + canvas.width / 2;
                                const y = star.y / star.z * canvas.height + canvas.height / 2;
                                const size = (1 - star.z / canvas.width) * star.size * 2;
                                const brightness = 1 - star.z / canvas.width;
                                const alpha = Math.min(1, 0.15 + brightness * 0.85);
                                ctx.fillStyle = `rgba(${starColor[0]}, ${starColor[1]}, ${starColor[2]}, ${alpha})`;
                                ctx.beginPath();
                                ctx.arc(x, y, Math.max(size, 0.4), 0, Math.PI * 2);
                                ctx.fill();
                            }
                        }["StarfieldBackground[useEffect() > animate > stars.forEach()]"]);
                        animationFrameId = requestAnimationFrame(animate);
                    }
                }["StarfieldBackground[useEffect() > animate]"];
                animate();
                const handleResize = {
                    "StarfieldBackground[useEffect() > handleResize]": ()=>{
                        resize();
                        seedStars();
                    }
                }["StarfieldBackground[useEffect() > handleResize]"];
                window.addEventListener("resize", handleResize);
                return ()=>{
                    if (animationFrameId) {
                        cancelAnimationFrame(animationFrameId);
                    }
                    window.removeEventListener("resize", handleResize);
                };
            }
        })["StarfieldBackground[useEffect()]"];
        t7 = [
            density,
            speed,
            starColor,
            trailOpacity
        ];
        $[1] = density;
        $[2] = speed;
        $[3] = starColor;
        $[4] = trailOpacity;
        $[5] = t6;
        $[6] = t7;
    } else {
        t6 = $[5];
        t7 = $[6];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t6, t7);
    let t8;
    if ($[7] !== backgroundGradient) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
            ref: canvasRef,
            className: "fixed inset-0 w-full h-full -z-30",
            style: {
                background: backgroundGradient
            }
        }, void 0, false, {
            fileName: "[project]/src/components/StarfieldBackground.tsx",
            lineNumber: 131,
            columnNumber: 10
        }, this);
        $[7] = backgroundGradient;
        $[8] = t8;
    } else {
        t8 = $[8];
    }
    return t8;
}
_s(StarfieldBackground, "UJgi7ynoup7eqypjnwyX/s32POg=");
_c = StarfieldBackground;
var _c;
__turbopack_context__.k.register(_c, "StarfieldBackground");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/MatrixRain.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MatrixRain
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ThemeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/ThemeContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function MatrixRain() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "0d80188ad0f7d589eb6bd0462f56d52252999170e62dc7b6c2568766d518b704") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "0d80188ad0f7d589eb6bd0462f56d52252999170e62dc7b6c2568766d518b704";
    }
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const { currentTheme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ThemeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const themeName = currentTheme.name;
    let t0;
    let t1;
    if ($[1] !== themeName) {
        t0 = ({
            "MatrixRain[useEffect()]": ()=>{
                if (themeName !== "matrix") {
                    return;
                }
                const canvas = canvasRef.current;
                if (!canvas) {
                    return;
                }
                const ctx = canvas.getContext("2d");
                if (!ctx) {
                    return;
                }
                const c = canvas;
                const context = ctx;
                const resize = {
                    "MatrixRain[useEffect() > resize]": ()=>{
                        c.width = window.innerWidth;
                        c.height = window.innerHeight;
                    }
                }["MatrixRain[useEffect() > resize]"];
                resize();
                const columns = Math.floor(c.width / 16);
                const drops = new Array(columns).fill(1);
                function draw() {
                    if (themeName !== "matrix") {
                        return;
                    }
                    context.fillStyle = "rgba(0,0,0,0.08)";
                    context.fillRect(0, 0, c.width, c.height);
                    context.fillStyle = "#00ff41";
                    context.font = 16 + "px monospace";
                    for(let i = 0; i < drops.length; i++){
                        const text = "01\u01B5\u2234\u2736\u2727\u203B"[Math.floor(Math.random() * 7)];
                        context.fillText(text, i * 16, drops[i] * 16);
                        if (drops[i] * 16 > c.height && Math.random() > 0.975) {
                            drops[i] = 0;
                        }
                        drops[i] = drops[i] + 1;
                    }
                    requestAnimationFrame(draw);
                }
                draw();
                window.addEventListener("resize", resize);
                return ()=>window.removeEventListener("resize", resize);
            }
        })["MatrixRain[useEffect()]"];
        t1 = [
            themeName
        ];
        $[1] = themeName;
        $[2] = t0;
        $[3] = t1;
    } else {
        t0 = $[2];
        t1 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    let t2;
    if ($[4] !== themeName) {
        t2 = themeName === "matrix" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
            ref: canvasRef,
            className: "fixed inset-0 -z-20 opacity-70"
        }, void 0, false, {
            fileName: "[project]/src/components/MatrixRain.tsx",
            lineNumber: 80,
            columnNumber: 35
        }, this) : null;
        $[4] = themeName;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    return t2;
}
_s(MatrixRain, "MF2utarbN/YKTTY2RHm2Lpe9Y9I=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ThemeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c = MatrixRain;
var _c;
__turbopack_context__.k.register(_c, "MatrixRain");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/CyberGrid.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CyberGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ThemeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/ThemeContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function CyberGrid() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "caa236d8e916a3829882beb2b8df70081d72a86265154c5fcb21883d1e1034a3") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "caa236d8e916a3829882beb2b8df70081d72a86265154c5fcb21883d1e1034a3";
    }
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const { currentTheme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ThemeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const themeName = currentTheme.name;
    let t0;
    let t1;
    if ($[1] !== themeName) {
        t0 = ({
            "CyberGrid[useEffect()]": ()=>{
                if (themeName !== "cyberpunk") {
                    return;
                }
                const canvas = canvasRef.current;
                if (!canvas) {
                    return;
                }
                const ctx = canvas.getContext("2d");
                if (!ctx) {
                    return;
                }
                const c = canvas;
                const context = ctx;
                const resize = {
                    "CyberGrid[useEffect() > resize]": ()=>{
                        canvas.width = window.innerWidth;
                        canvas.height = window.innerHeight;
                    }
                }["CyberGrid[useEffect() > resize]"];
                resize();
                let t = 0;
                function draw() {
                    if (themeName !== "cyberpunk") {
                        return;
                    }
                    context.clearRect(0, 0, c.width, c.height);
                    context.strokeStyle = "rgba(255,0,255,0.25)";
                    context.lineWidth = 1;
                    for(let x = 0; x < c.width; x = x + 40, x){
                        context.beginPath();
                        context.moveTo(x, 0);
                        const wave = Math.sin((x + t) * 0.02) * 10;
                        context.lineTo(x + wave, c.height);
                        context.stroke();
                    }
                    for(let y = 0; y < c.height; y = y + 40, y){
                        context.beginPath();
                        const wave_0 = Math.cos((y + t) * 0.02) * 10;
                        context.moveTo(0, y);
                        context.lineTo(c.width, y + wave_0);
                        context.stroke();
                    }
                    t = t + 1.5;
                    t;
                    requestAnimationFrame(draw);
                }
                draw();
                window.addEventListener("resize", resize);
                return ()=>window.removeEventListener("resize", resize);
            }
        })["CyberGrid[useEffect()]"];
        t1 = [
            themeName
        ];
        $[1] = themeName;
        $[2] = t0;
        $[3] = t1;
    } else {
        t0 = $[2];
        t1 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    let t2;
    if ($[4] !== themeName) {
        t2 = themeName === "cyberpunk" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
            ref: canvasRef,
            className: "fixed inset-0 -z-20 opacity-60"
        }, void 0, false, {
            fileName: "[project]/src/components/CyberGrid.tsx",
            lineNumber: 86,
            columnNumber: 38
        }, this) : null;
        $[4] = themeName;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    return t2;
}
_s(CyberGrid, "MF2utarbN/YKTTY2RHm2Lpe9Y9I=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ThemeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c = CyberGrid;
var _c;
__turbopack_context__.k.register(_c, "CyberGrid");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/QuantumBubbles.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
"use client";
;
;
;
;
const BUBBLE_PRESETS = {
    "deep-space": [
        {
            id: "ds-1",
            size: 320,
            x: 8,
            y: 18,
            color: "rgba(249,217,118,0.15)",
            blur: 65
        },
        {
            id: "ds-2",
            size: 260,
            x: 72,
            y: 24,
            color: "rgba(50,230,255,0.12)",
            blur: 55
        },
        {
            id: "ds-3",
            size: 220,
            x: 45,
            y: 74,
            color: "rgba(155,92,255,0.14)",
            blur: 50
        },
        {
            id: "ds-4",
            size: 160,
            x: 12,
            y: 70,
            color: "rgba(255,128,229,0.08)",
            blur: 45
        }
    ],
    "planet-orbit": [
        {
            id: "po-1",
            size: 280,
            x: 20,
            y: 30,
            color: "rgba(249,217,118,0.18)",
            blur: 70
        },
        {
            id: "po-2",
            size: 200,
            x: 70,
            y: 40,
            color: "rgba(50,230,255,0.16)",
            blur: 60
        },
        {
            id: "po-3",
            size: 240,
            x: 60,
            y: 75,
            color: "rgba(155,92,255,0.15)",
            blur: 65
        }
    ],
    "galactic-core": [
        {
            id: "gc-1",
            size: 360,
            x: 15,
            y: 25,
            color: "rgba(249,217,118,0.12)",
            blur: 90
        },
        {
            id: "gc-2",
            size: 300,
            x: 55,
            y: 35,
            color: "rgba(50,230,255,0.14)",
            blur: 80
        },
        {
            id: "gc-3",
            size: 220,
            x: 78,
            y: 68,
            color: "rgba(155,92,255,0.16)",
            blur: 70
        },
        {
            id: "gc-4",
            size: 180,
            x: 32,
            y: 80,
            color: "rgba(255,128,229,0.1)",
            blur: 60
        }
    ]
};
function createInstances(mode, density) {
    const preset = BUBBLE_PRESETS[mode];
    const normalize = (bubble, idx)=>({
            ...bubble,
            delay: bubble.delay ?? (Math.sin(idx * 1.73) + 1) * 4
        });
    const normalized = preset.map((bubble, idx)=>normalize(bubble, idx));
    if (density === "high") {
        const clones = normalized.map((bubble, idx)=>normalize({
                ...bubble,
                id: `${bubble.id}-clone-${idx}`,
                size: bubble.size * 0.65,
                x: (bubble.x + 12 + idx * 7) % 100,
                y: (bubble.y + 18 + idx * 11) % 100,
                opacity: 0.08
            }, idx + normalized.length));
        return [
            ...normalized,
            ...clones
        ];
    }
    if (density === "low") {
        return normalized.slice(0, Math.max(2, Math.floor(normalized.length / 2)));
    }
    return normalized;
}
function QuantumBubblesComponent(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(8);
    if ($[0] !== "9bd0a712637f932d5870b7abb1aff813856f97ea7e3f885e4236413a8e17ef00") {
        for(let $i = 0; $i < 8; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "9bd0a712637f932d5870b7abb1aff813856f97ea7e3f885e4236413a8e17ef00";
    }
    const { mode: t1, density: t2 } = t0;
    const mode = t1 === undefined ? "deep-space" : t1;
    const density = t2 === undefined ? "medium" : t2;
    let t3;
    if ($[1] !== density || $[2] !== mode) {
        t3 = createInstances(mode, density);
        $[1] = density;
        $[2] = mode;
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    const bubbles = t3;
    let t4;
    if ($[4] !== bubbles) {
        t4 = bubbles.map(_QuantumBubblesComponentBubblesMap);
        $[4] = bubbles;
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "pointer-events-none fixed inset-0 -z-10 overflow-hidden",
            children: t4
        }, void 0, false, {
            fileName: "[project]/src/components/QuantumBubbles.tsx",
            lineNumber: 160,
            columnNumber: 10
        }, this);
        $[6] = t4;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    return t5;
}
_c = QuantumBubblesComponent;
function _QuantumBubblesComponentBubblesMap(bubble) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("absolute rounded-full bg-gradient-radial from-white/30 to-transparent", "animate-bubble-drift"),
        style: {
            width: `${bubble.size}px`,
            height: `${bubble.size}px`,
            left: `${bubble.x}%`,
            top: `${bubble.y}%`,
            background: `radial-gradient(circle at 30% 30%, ${bubble.color}, transparent 70%)`,
            filter: `blur(${bubble.blur ?? 45}px)`,
            opacity: bubble.opacity ?? 0.6,
            animationDelay: `${bubble.delay ?? 0}s`
        }
    }, bubble.id, false, {
        fileName: "[project]/src/components/QuantumBubbles.tsx",
        lineNumber: 169,
        columnNumber: 10
    }, this);
}
const QuantumBubbles = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(QuantumBubblesComponent);
_c1 = QuantumBubbles;
const __TURBOPACK__default__export__ = QuantumBubbles;
var _c, _c1;
__turbopack_context__.k.register(_c, "QuantumBubblesComponent");
__turbopack_context__.k.register(_c1, "QuantumBubbles");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/BackgroundOrchestrator.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BackgroundOrchestrator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$StarfieldBackground$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/StarfieldBackground.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MatrixRain$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MatrixRain.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CyberGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/CyberGrid.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$QuantumBubbles$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/QuantumBubbles.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ThemeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/ThemeContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ObservatoryContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/ObservatoryContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
const OBSERVATORY_PRESETS = {
    'deep-space': {
        starfield: {
            starColor: [
                255,
                217,
                118
            ],
            density: 260,
            speed: 2.4,
            trailOpacity: 0.08,
            backgroundGradient: 'radial-gradient(circle at 20% 20%, rgba(13,17,35,0.95), rgba(2,3,8,0.98))'
        },
        bubbleDensity: 'medium'
    },
    'planet-orbit': {
        starfield: {
            starColor: [
                90,
                200,
                255
            ],
            density: 300,
            speed: 3,
            trailOpacity: 0.06,
            backgroundGradient: 'radial-gradient(circle at 60% 10%, rgba(6,14,32,0.92), rgba(2,4,18,0.98))'
        },
        bubbleDensity: 'high'
    },
    'galactic-core': {
        starfield: {
            starColor: [
                200,
                118,
                255
            ],
            density: 320,
            speed: 3.2,
            trailOpacity: 0.05,
            backgroundGradient: 'radial-gradient(circle at 40% 60%, rgba(22,8,32,0.9), rgba(4,2,12,0.98))'
        },
        bubbleDensity: 'medium'
    }
};
function BackgroundOrchestrator() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17);
    if ($[0] !== "7727c3f691fd39145ffcc3ed2cf00e1247696669b5de6cb1056a6112f6ae650e") {
        for(let $i = 0; $i < 17; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7727c3f691fd39145ffcc3ed2cf00e1247696669b5de6cb1056a6112f6ae650e";
    }
    const { currentTheme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ThemeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const { mode } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ObservatoryContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useObservatory"])();
    const themeName = currentTheme.name;
    const observatory = OBSERVATORY_PRESETS[mode];
    let t0;
    if ($[1] !== observatory.starfield || $[2] !== themeName) {
        t0 = (themeName === "cosmic" || themeName === "sacred") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$StarfieldBackground$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            ...observatory.starfield
        }, void 0, false, {
            fileName: "[project]/src/components/BackgroundOrchestrator.tsx",
            lineNumber: 60,
            columnNumber: 64
        }, this);
        $[1] = observatory.starfield;
        $[2] = themeName;
        $[3] = t0;
    } else {
        t0 = $[3];
    }
    let t1;
    if ($[4] !== themeName) {
        t1 = themeName === "matrix" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MatrixRain$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/BackgroundOrchestrator.tsx",
            lineNumber: 69,
            columnNumber: 36
        }, this);
        $[4] = themeName;
        $[5] = t1;
    } else {
        t1 = $[5];
    }
    let t2;
    if ($[6] !== themeName) {
        t2 = themeName === "cyberpunk" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CyberGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/components/BackgroundOrchestrator.tsx",
            lineNumber: 77,
            columnNumber: 39
        }, this);
        $[6] = themeName;
        $[7] = t2;
    } else {
        t2 = $[7];
    }
    let t3;
    if ($[8] !== mode || $[9] !== observatory.bubbleDensity) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$QuantumBubbles$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            mode: mode,
            density: observatory.bubbleDensity
        }, void 0, false, {
            fileName: "[project]/src/components/BackgroundOrchestrator.tsx",
            lineNumber: 85,
            columnNumber: 10
        }, this);
        $[8] = mode;
        $[9] = observatory.bubbleDensity;
        $[10] = t3;
    } else {
        t3 = $[10];
    }
    let t4;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "pointer-events-none fixed inset-0 -z-40 bg-[radial-gradient(circle_at_50%_20%,rgba(10,12,28,0.65),rgba(0,0,0,0.95))]"
        }, void 0, false, {
            fileName: "[project]/src/components/BackgroundOrchestrator.tsx",
            lineNumber: 94,
            columnNumber: 10
        }, this);
        $[11] = t4;
    } else {
        t4 = $[11];
    }
    let t5;
    if ($[12] !== t0 || $[13] !== t1 || $[14] !== t2 || $[15] !== t3) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t0,
                t1,
                t2,
                t3,
                t4
            ]
        }, void 0, true);
        $[12] = t0;
        $[13] = t1;
        $[14] = t2;
        $[15] = t3;
        $[16] = t5;
    } else {
        t5 = $[16];
    }
    return t5;
}
_s(BackgroundOrchestrator, "WlJBIqWvXF0/6Gw2m7MWNwdlQ3k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ThemeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ObservatoryContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useObservatory"]
    ];
});
_c = BackgroundOrchestrator;
var _c;
__turbopack_context__.k.register(_c, "BackgroundOrchestrator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ThemeToggle.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ThemeToggle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/sparkles.js [app-client] (ecmascript) <export default as Sparkles>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Binary$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/binary.js [app-client] (ecmascript) <export default as Binary>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Zap$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/zap.js [app-client] (ecmascript) <export default as Zap>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/star.js [app-client] (ecmascript) <export default as Star>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ThemeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/ThemeContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const themeConfig = {
    cosmic: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"],
        emoji: '🌌',
        label: 'Cosmic'
    },
    matrix: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Binary$3e$__["Binary"],
        emoji: '💚',
        label: 'Matrix'
    },
    cyberpunk: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Zap$3e$__["Zap"],
        emoji: '🌃',
        label: 'Cyberpunk'
    },
    sacred: {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"],
        emoji: '🕉️',
        label: 'Sacred'
    }
};
function ThemeToggle() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(20);
    if ($[0] !== "10deeb9712e391fd69985342cc9415d57b56976e4dbc88ce5de3ca8652e545d8") {
        for(let $i = 0; $i < 20; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "10deeb9712e391fd69985342cc9415d57b56976e4dbc88ce5de3ca8652e545d8";
    }
    const { currentTheme, setTheme, availableThemes } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ThemeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const CurrentIcon = themeConfig[currentTheme.name]?.icon || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"];
    let t0;
    if ($[1] !== isOpen) {
        t0 = ({
            "ThemeToggle[<motion.button>.onClick]": ()=>setIsOpen(!isOpen)
        })["ThemeToggle[<motion.button>.onClick]"];
        $[1] = isOpen;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    let t1;
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            scale: 1.05
        };
        t2 = {
            scale: 0.95
        };
        $[3] = t1;
        $[4] = t2;
    } else {
        t1 = $[3];
        t2 = $[4];
    }
    let t3;
    if ($[5] !== CurrentIcon) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CurrentIcon, {
            className: "w-6 h-6 text-zion-gold"
        }, void 0, false, {
            fileName: "[project]/src/components/ThemeToggle.tsx",
            lineNumber: 72,
            columnNumber: 10
        }, this);
        $[5] = CurrentIcon;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] !== t0 || $[8] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
            onClick: t0,
            whileHover: t1,
            whileTap: t2,
            className: "fixed bottom-4 right-4 z-50 h-12 w-12 rounded-full border border-white/20 bg-black/60 backdrop-blur flex items-center justify-center hover:border-zion-gold/60 hover:shadow-[0_0_20px_rgba(255,215,0,0.35)] transition-all",
            "aria-label": "Toggle theme menu",
            children: t3
        }, void 0, false, {
            fileName: "[project]/src/components/ThemeToggle.tsx",
            lineNumber: 80,
            columnNumber: 10
        }, this);
        $[7] = t0;
        $[8] = t3;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    let t5;
    if ($[10] !== availableThemes || $[11] !== currentTheme.name || $[12] !== isOpen || $[13] !== setTheme) {
        t5 = isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        opacity: 0,
                        scale: 0.9,
                        y: 20
                    },
                    animate: {
                        opacity: 1,
                        scale: 1,
                        y: 0
                    },
                    exit: {
                        opacity: 0,
                        scale: 0.9,
                        y: 20
                    },
                    transition: {
                        duration: 0.2
                    },
                    className: "fixed bottom-20 right-4 w-72 bg-black/90 backdrop-blur-xl border border-white/20 rounded-xl shadow-2xl overflow-hidden z-50",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-xs text-gray-400 px-3 py-2 font-semibold uppercase tracking-wide",
                                    children: "Choose Theme"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ThemeToggle.tsx",
                                    lineNumber: 103,
                                    columnNumber: 167
                                }, this),
                                availableThemes.map({
                                    "ThemeToggle[availableThemes.map()]": (theme)=>{
                                        const config = themeConfig[theme.name];
                                        config?.icon || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"];
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: {
                                                "ThemeToggle[availableThemes.map() > <button>.onClick]": ()=>{
                                                    setTheme(theme.name);
                                                    setIsOpen(false);
                                                }
                                            }["ThemeToggle[availableThemes.map() > <button>.onClick]"],
                                            className: `w-full flex items-center gap-3 px-3 py-3 rounded-lg transition-all ${currentTheme.name === theme.name ? "bg-white/20" : "hover:bg-white/10"}`,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-2xl",
                                                    children: config?.emoji
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ThemeToggle.tsx",
                                                    lineNumber: 112,
                                                    columnNumber: 230
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-1 text-left",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "font-semibold text-sm",
                                                            children: theme.displayName
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ThemeToggle.tsx",
                                                            lineNumber: 112,
                                                            columnNumber: 313
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-1 mt-1",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "w-3 h-3 rounded-full ring-1 ring-white/20",
                                                                    style: {
                                                                        backgroundColor: theme.colors.primary
                                                                    }
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/ThemeToggle.tsx",
                                                                    lineNumber: 112,
                                                                    columnNumber: 423
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "w-3 h-3 rounded-full ring-1 ring-white/20",
                                                                    style: {
                                                                        backgroundColor: theme.colors.secondary
                                                                    }
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/ThemeToggle.tsx",
                                                                    lineNumber: 114,
                                                                    columnNumber: 26
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "w-3 h-3 rounded-full ring-1 ring-white/20",
                                                                    style: {
                                                                        backgroundColor: theme.colors.accent
                                                                    }
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/ThemeToggle.tsx",
                                                                    lineNumber: 116,
                                                                    columnNumber: 26
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/ThemeToggle.tsx",
                                                            lineNumber: 112,
                                                            columnNumber: 377
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/ThemeToggle.tsx",
                                                    lineNumber: 112,
                                                    columnNumber: 279
                                                }, this),
                                                currentTheme.name === theme.name && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                                    className: "w-5 h-5 text-green-400"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ThemeToggle.tsx",
                                                    lineNumber: 118,
                                                    columnNumber: 75
                                                }, this)
                                            ]
                                        }, theme.name, true, {
                                            fileName: "[project]/src/components/ThemeToggle.tsx",
                                            lineNumber: 107,
                                            columnNumber: 22
                                        }, this);
                                    }
                                }["ThemeToggle[availableThemes.map()]"])
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/ThemeToggle.tsx",
                            lineNumber: 103,
                            columnNumber: 146
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "border-t border-white/10 p-3 bg-black/50",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-gray-400 text-center",
                                children: "✨ Theme saved automatically"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ThemeToggle.tsx",
                                lineNumber: 120,
                                columnNumber: 116
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/ThemeToggle.tsx",
                            lineNumber: 120,
                            columnNumber: 58
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ThemeToggle.tsx",
                    lineNumber: 89,
                    columnNumber: 22
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "fixed inset-0 z-40",
                    onClick: {
                        "ThemeToggle[<div>.onClick]": ()=>setIsOpen(false)
                    }["ThemeToggle[<div>.onClick]"]
                }, void 0, false, {
                    fileName: "[project]/src/components/ThemeToggle.tsx",
                    lineNumber: 120,
                    columnNumber: 215
                }, this)
            ]
        }, void 0, true);
        $[10] = availableThemes;
        $[11] = currentTheme.name;
        $[12] = isOpen;
        $[13] = setTheme;
        $[14] = t5;
    } else {
        t5 = $[14];
    }
    let t6;
    if ($[15] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
            children: t5
        }, void 0, false, {
            fileName: "[project]/src/components/ThemeToggle.tsx",
            lineNumber: 133,
            columnNumber: 10
        }, this);
        $[15] = t5;
        $[16] = t6;
    } else {
        t6 = $[16];
    }
    let t7;
    if ($[17] !== t4 || $[18] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative",
            children: [
                t4,
                t6
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ThemeToggle.tsx",
            lineNumber: 141,
            columnNumber: 10
        }, this);
        $[17] = t4;
        $[18] = t6;
        $[19] = t7;
    } else {
        t7 = $[19];
    }
    return t7;
}
_s(ThemeToggle, "T3m9OvavvLzbRmUR/njCH/Nuy3A=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ThemeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c = ThemeToggle;
var _c;
__turbopack_context__.k.register(_c, "ThemeToggle");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_fa813f35._.js.map