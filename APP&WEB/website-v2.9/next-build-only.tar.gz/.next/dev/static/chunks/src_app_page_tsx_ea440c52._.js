(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_components_7aaedba3._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_4de7eae2._.js"
],
    source: "dynamic"
});
