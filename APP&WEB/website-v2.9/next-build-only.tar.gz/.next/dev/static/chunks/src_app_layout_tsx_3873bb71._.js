(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__54567d6f._.css",
  "static/chunks/node_modules_af35a906._.js",
  "static/chunks/src_ae817484._.js"
],
    source: "dynamic"
});
