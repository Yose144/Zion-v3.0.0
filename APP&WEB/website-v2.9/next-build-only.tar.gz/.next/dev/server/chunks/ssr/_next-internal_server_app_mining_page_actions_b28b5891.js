module.exports = [
"[project]/.next-internal/server/app/mining/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=_next-internal_server_app_mining_page_actions_b28b5891.js.map