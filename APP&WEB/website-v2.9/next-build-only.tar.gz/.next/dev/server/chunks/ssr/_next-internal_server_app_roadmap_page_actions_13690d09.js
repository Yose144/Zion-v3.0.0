module.exports = [
"[project]/.next-internal/server/app/roadmap/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=_next-internal_server_app_roadmap_page_actions_13690d09.js.map