module.exports = [
"[project]/.next-internal/server/app/warp/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=_next-internal_server_app_warp_page_actions_ffe08096.js.map