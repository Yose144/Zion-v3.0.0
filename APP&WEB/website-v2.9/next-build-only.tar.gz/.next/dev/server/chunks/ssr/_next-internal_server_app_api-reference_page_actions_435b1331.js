module.exports = [
"[project]/.next-internal/server/app/api-reference/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=_next-internal_server_app_api-reference_page_actions_435b1331.js.map