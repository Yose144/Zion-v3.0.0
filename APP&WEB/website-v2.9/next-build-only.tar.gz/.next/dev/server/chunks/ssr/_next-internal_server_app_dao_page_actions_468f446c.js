module.exports = [
"[project]/.next-internal/server/app/dao/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=_next-internal_server_app_dao_page_actions_468f446c.js.map